import database.Account.AccountEntity;
import database.Account.AccountQuery;
import database.CCPurchase.CCPurchase;
import database.CCPurchase.CCPurchaseQuery;
import database.Customer.Customer;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

public class overView extends BankingApplication {

    //method return the scene of account overview
    public void display(Stage primaryStage, ObservableList<database> customer) {

        String FirstName = customer.get(0).getFname();
        String LastName = customer.get(0).getLname();
        String ssn = customer.get(0).getSSN();

        List<AccountEntity> acc = new AccountQuery().getBySSN(ssn).execute();
        for (int i = 0; i < acc.size(); i++) {
            if (acc.get(i).getTYPE().equals("Savings")) {
                haveSaving = true;
            }
            if (acc.get(i).getTYPE().equals("Checking")) {
                haveChecking = true;
            }
            if (acc.get(i).getTYPE().equals("Loan")) {
                haveLoan = true;
            }
            if (acc.get(i).getTYPE().equals("Credit")) {
                haveCredit = true;
            }
            if (acc.get(i).getTYPE().equals("CD")) {
                haveCD = true;
            }

        }
        //create text with date
        Text date = new Text(new Date().toString());
        Label title = new Label("Home Page");
        title.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 30");
        title.setAlignment(Pos.CENTER);
        date.setStyle("-fx-fill: white; -fx-stroke: white");
        //create label for customer name
        Label greeting = new Label("Welcome, ");
        Label Fname = new Label(FirstName);
        Label Lname = new Label(" " + LastName);
        greeting.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Fname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Lname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        //list all the accounts as hyperlinks along with checkboxes showing whether the accounts are available
        Text accounts = new Text("Accounts:");
        accounts.setFill(Color.WHITE);
        accounts.setFont(Font.font(null, 20));
        Text available = new Text("Availability");
        available.setFill(Color.WHITE);
        available.setFont(Font.font(null, 20));
        accounts.setStyle("-fx-text-fill: white");
        Hyperlink checking = new Hyperlink("Checking");
        Hyperlink closeChecking = new Hyperlink("Close Checking");
        //action of all hyperlinks is to go to the account page of the indicated account
        checking.setOnAction(e -> {
            if (haveChecking == true) {
                checking checkingAcc = new checking();
                checkingAcc.display(primaryStage, customer);
            } else {
                CreateNewAccount newAccount = new CreateNewAccount();
                newAccount.display(primaryStage, customer, 1);
            }
        });
        closeChecking.setOnAction(e -> {
            if (ConfirmBox.display("Close Checking", "Are you sure? ", 0)) closeAccount(acc, 1);
        });
        Hyperlink loan = new Hyperlink("Loan");
        Hyperlink closeLoan = new Hyperlink("Close Loan");
        closeLoan.setOnAction(e -> {
            if (ConfirmBox.display("Close Loan", "Are you sure? ", 0)) closeAccount(acc, 4);
        });
        loan.setOnAction(e -> {
            if (haveLoan == true) {
                loan loanAcc = new loan();
                loanAcc.display(primaryStage, customer);
            } else {
                CreateNewAccount newAccount = new CreateNewAccount();
                newAccount.display(primaryStage, customer, 4);
            }
        });
        //create checkbox for each account showing availability
        Hyperlink saving = new Hyperlink("Savings");
        Hyperlink closeSaving = new Hyperlink("Close Savings");
        closeSaving.setOnAction(e -> {
            if (ConfirmBox.display("Close Savings", "Are you sure? ", 0)) closeAccount(acc, 2);
        });
        saving.setOnAction(e -> {
            if (haveSaving == true) {
                savings savingAcc = new savings();
                savingAcc.display(primaryStage, customer);
            } else {
                CreateNewAccount newAccount = new CreateNewAccount();
                newAccount.display(primaryStage, customer, 2);
            }
        });
        Hyperlink credit = new Hyperlink("Credit Card");
        Hyperlink closeCredit = new Hyperlink("Close Credit Card");
        closeCredit.setOnAction(e -> {
            if (ConfirmBox.display("Close Credit Card", "Are you sure? ", 0)) closeAccount(acc, 3);
        });
        credit.setOnAction(e -> {
            if (haveCredit == true) {
                CC creditCardAcc = new CC();
                creditCardAcc.display(primaryStage, customer);
            } else {
                CreateNewAccount newAccount = new CreateNewAccount();
                newAccount.display(primaryStage, customer, 3);
            }
        });

        Hyperlink certificateOfDepositd = new Hyperlink("Certificate of Deposit");
        Hyperlink closeCertificateOfDepositd = new Hyperlink("Close Certificate of Deposit");
        closeCertificateOfDepositd.setOnAction(e -> {
            if (ConfirmBox.display("Close CD account", "Are you sure? ", 0)) closeAccount(acc, 5);
        });
        certificateOfDepositd.setOnAction(e -> {
            if (haveCD == true) {
                CD cdAcc = new CD();
                cdAcc.display(primaryStage, customer);
            } else {
                CreateNewAccount newAccount = new CreateNewAccount();
                newAccount.display(primaryStage, customer, 5);
            }
        });

        CheckBox ch = new CheckBox();
        //each check box will only check if the boolean for that account is true
        ch.setSelected(haveChecking);
        ch.setDisable(true);
        CheckBox sa = new CheckBox();
        sa.setSelected(haveSaving);
        sa.setDisable(true);
        CheckBox cr = new CheckBox();
        cr.setSelected(haveCredit);
        cr.setDisable(true);
        CheckBox lo = new CheckBox();
        lo.setSelected(haveLoan);
        lo.setDisable(true);
        CheckBox cd = new CheckBox();
        cd.setSelected(haveCD);
        cd.setDisable(true);
        //create button for quit which will lead back to log in page
        Button quit = new Button("Quit");
        //quit button will go back to log in page and start over in log in lookup
        quit.setOnAction(e -> {
            try {
                start(primaryStage);
            } catch (Exception er) {
                er.printStackTrace();
            }
        });
        quit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button back = new Button("Back");
        back.setOnAction(e -> {
            lookUpAcc = new lookUp();
            lookUpAcc.display(primaryStage);
        });
        back.setStyle("-fx-background-color: yellow; -fx-text-fill: black");

        GridPane name = new GridPane();
        name.add(greeting, 0, 0);
        name.add(Fname, 1, 0);
        name.add(Lname, 2, 0);
        name.setAlignment(Pos.CENTER);
        HBox head = new HBox();
        head.getChildren().addAll(name, date);
        head.setSpacing(25);
        head.setAlignment(Pos.CENTER);
        //create pane to include all the elements
        GridPane pane = new GridPane();
        pane.add(accounts, 0, 0);
        //pane.add(available, 1,0);
        pane.add(checking, 0, 1);
        pane.add(ch, 1, 1);
        if (haveChecking == true) pane.add(closeChecking, 2, 1);
        pane.add(saving, 0, 2);
        pane.add(sa, 1, 2);
        if (haveSaving == true) pane.add(closeSaving, 2, 2);
        pane.add(credit, 0, 3);
        pane.add(cr, 1, 3);
        if (haveCredit == true) pane.add(closeCredit, 2, 3);
        pane.add(loan, 0, 4);
        pane.add(lo, 1, 4);
        if (haveLoan == true) pane.add(closeLoan, 2, 4);
        pane.add(certificateOfDepositd, 0, 5);
        pane.add(cd, 1, 5);
        if (haveCD == true) pane.add(closeCertificateOfDepositd, 2, 5);
        pane.setAlignment(Pos.CENTER);
        VBox mainPane = new VBox();
        mainPane.getChildren().addAll(head, title, pane, back, quit);
        //set some spacing between the elements
        pane.setVgap(25);
        pane.setHgap(150);
        mainPane.setStyle("-fx-background-color: black");
        mainPane.setAlignment(Pos.CENTER);
        mainPane.setSpacing(25);
        //add pane to scene
        scene = new Scene(mainPane, 700, 700);
        primaryStage.setScene(scene);
    }

    public void closeAccount(List<AccountEntity> acc, int accType) {
        double remainBalance = 0.;
        for (int i = 0; i < acc.size(); i++) {
            if (accType == 1 && acc.get(i).getTYPE().equals("Checking")) {
                remainBalance = acc.get(i).getBALANCE();
                acc.get(i).delete();
                AlertBox alertBox = new AlertBox();
                alertBox.display("Successfully", "Successfully Closed\n And here are your \nremain balance: $" + remainBalance);
            } else if (accType == 2 && acc.get(i).getTYPE().equals("Savings")) {
                remainBalance = acc.get(i).getFUTURE_VALUE();
                acc.get(i).delete();
                AlertBox alertBox = new AlertBox();
                alertBox.display("Successfully", "Successfully Closed\n And here are your \nremain balance: $" + remainBalance);
            } else if (accType == 3 && acc.get(i).getTYPE().equals("Credit")) {
                List<CCPurchase> delete=new CCPurchaseQuery().getBySSN(acc.get(i).getSSN()).execute();
                for(int j=delete.size()-1;j>=0;j--){
                    delete.get(j).delete();
                }
                remainBalance = acc.get(i).getBALANCE();
                acc.get(i).delete();
                AlertBox alertBox = new AlertBox();
                alertBox.display("Successfully", "Successfully Closed\n And here are your \nremain balance: $" + remainBalance);
            } else if (accType == 4 && acc.get(i).getTYPE().equals("Loan")) {
                if(acc.get(i).getFUTURE_VALUE()>0){
                AlertBox alertBox = new AlertBox();
                alertBox.display("Unsuccessfully", "Sorry, Will not be able to \n\tclose the account\n Please pay off your Amount");
                break;
                }else{
                acc.get(i).delete();
                AlertBox alertBox = new AlertBox();
                alertBox.display("Successfully", "Successfully Closed\n You are debit Free");
                acc.get(i).update();
                }
            } else if (accType == 5 && acc.get(i).getTYPE().equals("CD")) {
                LocalDate today = LocalDate.now();
                int period=acc.get(i).getTERM_PERIOD();
                LocalDate dateCanGainAllMoney = LocalDate.parse(acc.get(i).getDATE_CREATED(), DateTimeFormatter.ofPattern("MM/dd/uuuu")).plusYears(period);
                if (dateCanGainAllMoney.isAfter(today)) {
                    ConfirmBox confirmBox = new ConfirmBox();

                    if (confirmBox.display("Confirm", "You will lose all the interest\n\tCountinus?", 5)) {
                        AlertBox alertBox = new AlertBox();
                        alertBox.display("Successfully", "Successfully Closed\n And here are your \nremain balance: $" + acc.get(i).getBALANCE());
                        acc.get(i).delete();
                    }

                } else {
                    remainBalance = acc.get(i).getFUTURE_VALUE();
                    acc.get(i).delete();
                    AlertBox alertBox = new AlertBox();
                    alertBox.display("Successfully", "Successfully Closed\n And here are your \nremain balance: $" + remainBalance);
                }
            }
        }

    }
}