import database.Account.AccountEntity;
import database.Account.AccountQuery;
import database.CCPurchase.CCPurchase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;

import javax.swing.text.Document;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class loan extends overView {
    double INTEREST_RATE, minPay;
    Text MinPayment;
    String dateCreated;
    String dueDate, lastpaymentdate;
    double Payment = 0.0;

    public void display(Stage primaryStage, ObservableList<database> customer) {
        //name label
        String FirstName = customer.get(0).getFname();
        String LastName = customer.get(0).getLname();
        String ssn = customer.get(0).getSSN();
        //find the matching ssn
        List<AccountEntity> acc = new AccountQuery().getBySSN(ssn).getByType("Loan").execute();
        dateCreated = acc.get(0).getDATE_CREATED();
        lastpaymentdate = acc.get(0).getDATE_NEXT_PAYMENT_DUE();
        String OverAllBalance = String.valueOf(acc.get(0).getBALANCE());
        double balance = Double.parseDouble(OverAllBalance);

        //basic oouput customer info
        Label greeting = new Label("Hello, ");
        Label Fname = new Label(FirstName);
        Label Lname = new Label(" " + LastName);
        greeting.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Fname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Lname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        //title:checking
        Label title = new Label("Loan");
        title.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 25");
        //Payment Due Date
        Text createdD = new Text("Payment created date:");
        createdD.setFont(Font.font(null, 20));
        createdD.setFill(Color.WHITE);
        Text dueD = new Text("Last Payment:" + acc.get(0).getDATE_NEXT_PAYMENT_DUE());
        dueD.setFont(Font.font(null, 20));
        dueD.setFill(Color.WHITE);
        Text dueday = new Text(dateCreated);
        dueday.setFont(Font.font(null, 20));
        dueday.setFill(Color.WHITE);
        //term period
        Label tPeriod = new Label("Term: " + acc.get(0).getSUBTYPE());
        tPeriod.setStyle("-fx-text-fill: red; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 16");
        //Minimum Payment
        Text MinP = new Text("Minimum Payment:");
        MinP.setFont(Font.font(null, 20));
        MinP.setFill(Color.WHITE);
        //account overview: balance
        Text balanceOA = new Text("Initial Balance:");
        balanceOA.setFont(Font.font(null, 20));
        balanceOA.setFill(Color.WHITE);
        Text OVBalance = new Text(OverAllBalance);
        OVBalance.setTextAlignment(TextAlignment.LEFT);
        OVBalance.setFont(Font.font(null, 20));
        OVBalance.setFill(Color.WHITE);
        Text interestR = new Text("Interest Rate:");
        interestR.setFont(Font.font(null, 20));
        interestR.setFill(Color.WHITE);
        Text interestRate = new Text(String.valueOf(acc.get(0).getINTEREST_RATE()));
        interestRate.setTextAlignment(TextAlignment.LEFT);
        interestRate.setFont(Font.font(null, 20));
        interestRate.setFill(Color.WHITE);
        //edit interest rate
        Label update = new Label("Update Interest Rate: ");
        update.setStyle("-fx-text-fill: red; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        TextField updateIR = new TextField();
        updateIR.setPrefWidth(50);
        int termPeriod = acc.get(0).getTERM_PERIOD();
        MinPayment = new Text(String.valueOf(minPayment(balance, termPeriod, interestRate.getText())));
        MinPayment.setFont(Font.font(null, 20));
        MinPayment.setFill(Color.WHITE);
        minPay = Double.parseDouble(minPayment(balance, termPeriod, interestRate.getText()));
        acc.get(0).setMINIMUM_PAYMENT(minPay);
        acc.get(0).setFUTURE_VALUE(CalculateFutureAmount(minPay, termPeriod));
        acc.get(0).update();
        Text Amount = new Text("Amount Owned: " + CalculateBalanceLeftOver(acc));
        Amount.setFont(Font.font(null, 20));
        Amount.setFill(Color.WHITE);

        Label paymenttitle = new Label("Make a Payment");
        paymenttitle.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 25");
        Text setPDate = new Text("Set Payment Date:");
        setPDate.setFont(Font.font(null, 20));
        setPDate.setFill(Color.WHITE);
        DatePicker dateP = new DatePicker();
        LocalDate localDate = dateP.getValue();
        ToggleGroup RadioBGroup = new ToggleGroup();
        RadioButton CurrentB = new RadioButton("Current Balance :");
        CurrentB.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        Text currentBalance = new Text(String.valueOf(CalculateBalanceLeftOver(acc)));
        currentBalance.setFont(Font.font(null, 20));
        currentBalance.setFill(Color.WHITE);
        CurrentB.setToggleGroup(RadioBGroup);
        RadioButton MinB = new RadioButton("Minimun Balance :");
        MinB.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        Text MinBalance = new Text(String.valueOf(acc.get(0).getMINIMUM_PAYMENT()));
        MinBalance.setFont(Font.font(null, 20));
        MinBalance.setFill(Color.WHITE);
        CurrentB.setToggleGroup(RadioBGroup);
        MinB.setToggleGroup(RadioBGroup);
        RadioButton other = new RadioButton("Other:");
        other.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        TextField payAmount = new TextField();
        payAmount.setPrefWidth(120);
        other.setToggleGroup(RadioBGroup);
        GridPane setPaymentdate = new GridPane();
        setPaymentdate.add(setPDate, 0, 0);
        setPaymentdate.add(dateP, 1, 0);
        setPaymentdate.setHgap(25);
        setPaymentdate.setAlignment(Pos.CENTER);
        GridPane pOptions = new GridPane();
        pOptions.add(CurrentB, 0, 0);
        pOptions.add(currentBalance, 1, 0);
        pOptions.add(MinB, 0, 1);
        pOptions.add(MinBalance, 1, 1);
        pOptions.add(other, 0, 2);
        pOptions.add(payAmount, 1, 2);
        pOptions.setVgap(20);
        pOptions.setAlignment(Pos.CENTER);

        Button makePayment = new Button("Pay");
        dateP.setOnAction(e -> {
            dueDate = dateP.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        });
        makePayment.setOnAction(e -> {
            if (CurrentB.isSelected()) {
                Payment = CalculateBalanceLeftOver(acc);
                Amount.setText("Amount Owned: 0" );
                acc.get(0).setFUTURE_VALUE(0);
                acc.get(0).setDATE_NEXT_PAYMENT_DUE(dueDate);
                dueD.setText("Last Payment:" + dueDate);
                acc.get(0).update();
                MinPayment.setText(minPayment(acc));
                MinBalance.setText(minPayment(acc));
                acc.get(0).setMINIMUM_PAYMENT(Double.parseDouble(minPayment(acc)));
                acc.get(0).update();
            } else if (MinB.isSelected()) {
                Payment = acc.get(0).getMINIMUM_PAYMENT();
                Amount.setText("Amount Owned: " + String.valueOf(CalculateBalanceLeftOver(acc) - Payment));
                acc.get(0).setFUTURE_VALUE(CalculateBalanceLeftOver(acc) - Payment);
                acc.get(0).setDATE_NEXT_PAYMENT_DUE(dueDate);
                dueD.setText("Last Payment:" + dueDate);
                acc.get(0).update();
                MinPayment.setText(minPayment(acc));
                MinBalance.setText(minPayment(acc));
                acc.get(0).setMINIMUM_PAYMENT(Double.parseDouble(minPayment(acc)));
                acc.get(0).update();
            } else if (other.isSelected()) {
                Payment = Double.parseDouble(payAmount.getText());
                Amount.setText(String.valueOf(CalculateBalanceLeftOver(acc) - Payment));
                acc.get(0).setFUTURE_VALUE(CalculateBalanceLeftOver(acc) - Payment);
                acc.get(0).setDATE_NEXT_PAYMENT_DUE(dueDate);
                dueD.setText("Last Payment:" + dueDate);
                acc.get(0).update();
                MinBalance.setText(minPayment(acc));
                MinPayment.setText(minPayment(acc));
                acc.get(0).setMINIMUM_PAYMENT(Double.parseDouble(minPayment(acc)));
                acc.get(0).update();
                // payment=Double.parseDouble(payAmount.getText());
                acc.get(0).update();
            } else {
                AlertBox alertBox = new AlertBox();
                alertBox.display("Warning", "please Select one of above");
            }
            List<AccountEntity> checkingacc = new AccountQuery().getBySSN(ssn).getByType("Checking").execute();
            currentBalance.setText(String.valueOf(CalculateBalanceLeftOver(acc)));
            checkingacc.get(0).setBALANCE(checkingacc.get(0).getBALANCE() - Payment);
            checkingacc.get(0).update();
        });

        //buttons for home, quite, and transfer money
        Button home = new Button("Home");
        home.setOnAction(e -> {
            overViewAcc = new overView();
            overViewAcc.display(primaryStage, customer);
        });
        home.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button quit = new Button("Quit");
        quit.setOnAction(e -> {
            try {
                start(primaryStage);
            } catch (Exception er) {
                er.printStackTrace();
            }
        });
        quit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button save = new Button("Save");
        save.setOnAction(e -> {
            interestRate.setText(updateIR.getText());
            MinPayment.setText(minPayment(acc,updateIR.getText()));
            acc.get(0).setINTEREST_RATE(Double.parseDouble(updateIR.getText()));
            acc.get(0).update();
            Amount.setText("Amount Owned: " + String.valueOf(CalculateBalanceLeftOver(acc)));
            acc.get(0).setFUTURE_VALUE(CalculateFutureAmount(minPay, termPeriod));
            acc.get(0).update();
        });
        save.setStyle("-fx-background-color: blue; -fx-text-fill: black");
        //create pane
        HBox action = new HBox();

        if (teller || manager) action.getChildren().addAll(home, quit, save);
        else action.getChildren().addAll(makePayment, home, quit);
        action.setSpacing(50);
        action.setAlignment(Pos.CENTER);
        ;//name grid
        GridPane name = new GridPane();
        name.add(greeting, 0, 0);
        name.add(Fname, 1, 0);
        name.add(Lname, 2, 0);
        name.add(tPeriod, 0, 1);
        name.setAlignment(Pos.CENTER);
        //customer payment info
        GridPane info = new GridPane();
        info.add(createdD, 0, 0);
        info.add(dueday, 1, 0);
        info.add(MinP, 0, 1);
        info.add(MinPayment, 1, 1);
        info.add(balanceOA, 0, 2);
        info.add(OVBalance, 1, 2);
        info.add(interestR, 0, 3);
        info.add(interestRate, 1, 3);
        info.setHgap(25);
        info.setVgap(25);
        info.setAlignment(Pos.CENTER);
        GridPane IR = new GridPane();
        IR.add(update, 0, 0);
        IR.add(updateIR, 1, 0);
        IR.setAlignment(Pos.CENTER);
        VBox pane = new VBox();
        if (teller || manager)
            pane.getChildren().addAll(name, title, info, Amount, IR, paymenttitle, dueD, setPaymentdate, pOptions, makePayment, action);
        else
            pane.getChildren().addAll(name, title, info, paymenttitle, dueD, setPaymentdate, pOptions, makePayment, action);
        pane.setStyle("-fx-background-color: black");
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(20);
        scene = new Scene(pane, 600, 900);
        primaryStage.setScene(scene);
    }
    public String minPayment(double balance,int lengthInYears,String rate) {

        INTEREST_RATE =Double.parseDouble(rate);
        double minPay = (balance / (lengthInYears * 12.0)) + ((balance / 2.0) * lengthInYears * INTEREST_RATE) / (lengthInYears * 12.0);
        String min = String.valueOf(minPay);
        return min;
    }
    public String minPayment(List<AccountEntity> acc) {
//        Date date = new Date();
        String DATE_FORMAT = "MM/dd/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        String currentDate = acc.get(0).getDATE_NEXT_PAYMENT_DUE();
        String beforeDate = acc.get(0).getDATE_CREATED();
        Date date1 = null;
        try {
            date1 = sdf.parse(currentDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Date date2 = null;
        try {
            date2 = sdf.parse(beforeDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long diff = date1.getTime() - date2.getTime();
        long daydiff = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
        double lengthInYears=acc.get(0).getTERM_PERIOD()-daydiff/365.0;
        System.out.println(lengthInYears+" years left");
        INTEREST_RATE = acc.get(0).getINTEREST_RATE();
        double balance=CalculateBalanceLeftOver(acc);
        double minPay = (balance / (lengthInYears * 12.0)) + ((balance / 2.0) * lengthInYears * INTEREST_RATE) / (lengthInYears * 12.0);
        String min = String.valueOf(minPay);
        return min;
    }
    public String minPayment(List<AccountEntity> acc,String rate) {
        double IR=Double.parseDouble(rate);
        Date date = new Date();
        String DATE_FORMAT = "MM/dd/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        String currentDate = sdf.format(date);
        String beforeDate = acc.get(0).getDATE_CREATED();
        Date date1 = null;
        try {
            date1 = sdf.parse(currentDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Date date2 = null;
        try {
            date2 = sdf.parse(beforeDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long diff = date1.getTime() - date2.getTime();
        long daydiff = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
        double lengthInYears=acc.get(0).getTERM_PERIOD()-daydiff/365.0;
        double balance=CalculateBalanceLeftOver(acc);
        double minPay = (balance / (lengthInYears * 12.0)) + ((balance / 2.0) * lengthInYears * IR) / (lengthInYears * 12.0);
        String min = String.valueOf(minPay);
        return min;
    }

    public double CalculateFutureAmount(double fAmount, int time) {

        double amount = fAmount * time * 12.0;

        return amount;
    }

    public double CalculateBalanceLeftOver(List<AccountEntity> acc) {
        double futureAmount = acc.get(0).getFUTURE_VALUE();
        double monthly = acc.get(0).getMINIMUM_PAYMENT();
        Date date = new Date();
        String DATE_FORMAT = "MM/dd/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        String currentDate = sdf.format(date);
        String beforeDate = acc.get(0).getDATE_CREATED();
        Date date1 = null;
        try {
            date1 = sdf.parse(currentDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Date date2 = null;
        try {
            date2 = sdf.parse(beforeDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long diff = date1.getTime() - date2.getTime();
        long daydiff = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
        double amount = futureAmount - daydiff / 30.0 * monthly;
        return amount;
    }

}