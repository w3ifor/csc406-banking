import database.Account.AccountEntity;
import database.Account.AccountQuery;
import database.CCPurchase.CCPurchase;
import database.CCPurchase.CCPurchaseQuery;
import database.Check.Check;
import database.Check.CheckQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;

import javax.swing.text.Document;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class makeAPayment extends CC {
    double payment=0.0;
    public void display(Stage primaryStage, ObservableList<database> customer, int accountType, String ssn) {
        String type;
        if (accountType == 3) {
            type = "Credit";
        } else {
            type = "Loan";
        }
        List<AccountEntity> acc = new AccountQuery().getBySSN(ssn).getByType(type).execute();
        Label title = new Label("Make a Payment");
        title.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 25");
        Text setPDate = new Text("Set Payment Date:");
        setPDate.setFont(Font.font(null, 20));
        setPDate.setFill(Color.WHITE);
        DatePicker dateP = new DatePicker();
        ToggleGroup RadioBGroup = new ToggleGroup();
        RadioButton CurrentB = new RadioButton("Current Balance :");
        CurrentB.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        Text currentBalance = new Text(String.valueOf(acc.get(0).getBALANCE()-acc.get(0).getFUTURE_VALUE()));
        currentBalance.setFont(Font.font(null, 20));
        currentBalance.setFill(Color.WHITE);
        CurrentB.setToggleGroup(RadioBGroup);
        RadioButton MinB = new RadioButton("Minimun Balance :");
        MinB.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        Text MinBalance = new Text(String.valueOf(acc.get(0).getMINIMUM_PAYMENT()));
        MinBalance.setFont(Font.font(null, 20));
        MinBalance.setFill(Color.WHITE);
        CurrentB.setToggleGroup(RadioBGroup);
        MinB.setToggleGroup(RadioBGroup);
        RadioButton other = new RadioButton("Other:");
        other.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        TextField payAmount = new TextField();
        payAmount.setPrefWidth(120);
        other.setToggleGroup(RadioBGroup);
        Button back = new Button("Back");
        back.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    if (accountType == 3) {
                        CC cc = new CC();
                        cc.display(primaryStage, customer);
                    } else {
                        loan loanAcc = new loan();
                        loanAcc.display(primaryStage, customer);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        back.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button quit = new Button("Quit");
        quit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    start(primaryStage);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        quit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button submit = new Button("Submit");
        submit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        submit.setOnAction(e->{
            if(CurrentB.isSelected()){
                System.out.println("pay with current balance");
                payment=acc.get(0).getBALANCE()-acc.get(0).getFUTURE_VALUE();
                acc.get(0).setFUTURE_VALUE(acc.get(0).getBALANCE());
                acc.get(0).update();
            }else if(MinB.isSelected()){
                System.out.println("pay with min balance");
                payment=acc.get(0).getMINIMUM_PAYMENT();
                System.out.println("date is "+dateP.getAccessibleText());
                System.out.println("payment is "+payment);
                acc.get(0).setDATE_NEXT_PAYMENT_DUE(dateP.getPromptText());
                acc.get(0).setFUTURE_VALUE(acc.get(0).getFUTURE_VALUE()+acc.get(0).getMINIMUM_PAYMENT());
                acc.get(0).update();
            }else if(other.isSelected()){
                System.out.println("pay with other balance");
                payment=Double.parseDouble(payAmount.getText());
                acc.get(0).setFUTURE_VALUE(acc.get(0).getFUTURE_VALUE()+(Double.parseDouble(payAmount.getText())));
                acc.get(0).update();
            }else{
                AlertBox alertBox=new AlertBox();
                alertBox.display("Warning","please Select one of above");
            }
        });

        //create pane
        GridPane setPaymentdate = new GridPane();
        setPaymentdate.add(setPDate, 0, 0);
        setPaymentdate.add(dateP, 1, 0);
        setPaymentdate.setHgap(25);
        setPaymentdate.setAlignment(Pos.CENTER);
        GridPane pOptions = new GridPane();
        pOptions.add(CurrentB, 0, 0);
        pOptions.add(currentBalance, 1, 0);
        pOptions.add(MinB, 0, 1);
        pOptions.add(MinBalance, 1, 1);
        pOptions.add(other, 0, 2);
        pOptions.add(payAmount, 1, 2);
        pOptions.setVgap(20);
        pOptions.setAlignment(Pos.CENTER);
        HBox action = new HBox();
        action.getChildren().addAll(submit, back, quit);
        action.setSpacing(50);
        action.setAlignment(Pos.CENTER);
        VBox pane = new VBox();
        pane.getChildren().addAll(title, setPaymentdate, pOptions, action);
        pane.setStyle("-fx-background-color: black");
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(20);
        scene = new Scene(pane, 700, 700);
        primaryStage.setScene(scene);
    }

    public double getPayment() {
        return payment;
    }
}