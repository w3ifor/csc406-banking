import com.sun.rowset.internal.Row;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;

//db imports
import database.Customer.Customer;
import database.Customer.CustomerQuery;


import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import java.util.List;

//Note:
//1.Some function have int value, that represent the type of account(1:checking,2:saving,3:Credit card,4:Loan)
public class BankingApplication extends Application {

    Scene scene; //the ever changing scene methods can change and return to the stage
    //boolean for all the users, it will be true for the one currently using the interface
    Boolean customer = false;
    Boolean teller = false;
    Boolean manager = true;
    //same boolean indication for accounts
    Boolean haveSaving = false;
    Boolean haveChecking = false;
    Boolean haveCredit = false;
    Boolean haveLoan = false;
    Boolean haveCD=false;
    //Customer information
    String State;
    TableView<database> availableCTable;
    ObservableList<database> customerFound;
    overView overViewAcc;
    lookUp lookUpAcc;
    withDraw withDrawCash;
    deposit depositCash;
    AlertBox alertbox;
    Button add;
    TextField fnameInput, lnameInput, addressInput, ssnInput, zipCodeInput, cityInput;


    public static void main(String[] args) {
        launch(args);
    }

    public void start(final Stage primaryStage) throws Exception {
        //title of the window
        primaryStage.setTitle("Griffon Bank");

        //set title of the first page
        Text title = new Text("Welcome to Griffon Bank");
        title.setFont(Font.font(null, FontWeight.BOLD, FontPosture.REGULAR, 50));
        title.setTextAlignment(TextAlignment.CENTER);
        //set title to yellow and the rest of the texts to white
        title.setFill(Color.YELLOW);
        //create introduction
        Text intro = new Text("Your personal assistant for banking on the go!\nPlease enter your log in information:");
        intro.setStroke(Color.WHITE);
        intro.setFill(Color.WHITE);
        intro.setStyle("-fx-font-size: 25");
        intro.setTextAlignment(TextAlignment.CENTER);
        //create label user ID and password along with input text field
        Label username = new Label("User Name");
        username.setTextFill(Color.WHITE);
        Label password = new Label("Password");
        password.setTextFill(Color.WHITE);
        TextField unInput = new TextField();
        //check if the username is all number
        unInput.setPrefColumnCount(20);
        PasswordField pwInput = new PasswordField();
        pwInput.setPrefColumnCount(20);
        //create quit and log in button
        Button quit = new Button("Quit");
        //action of quit button is closing window and ending program
        quit.setOnAction(e -> {
            if (ConfirmBox.display("Close Program", "Are you ready to leave? ", 0)) primaryStage.close();
            else {
                try {
                    start(primaryStage);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        //quit will close the window
        Button enter = new Button("Enter");
        //action of enter button is inputing the log in info, retrieving the user info, indicating the next page: customer lookup or overview of accounts
        enter.setOnAction(e -> {
            lookUpAcc = new lookUp();
            boolean vaildUserName = isInt.display(unInput, unInput.getText());
            if ((manager || teller) && vaildUserName == true)
                lookUpAcc.display(primaryStage);
            else if (customer && vaildUserName == true) overViewAcc.display(primaryStage, customerFound);
            else {
                alertbox.display("invalid user name", "Invalid user name");
                pwInput.clear();
                unInput.clear();
            }
        });
        quit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        enter.setStyle("-fx-background-color: yellow; -fx-text-fill: black");

        //create HBox for the user inputs and center the position
        GridPane inputPane = new GridPane();
        inputPane.setHgap(5);
        inputPane.setVgap(5);
        inputPane.add(username, 0, 0);
        inputPane.add(unInput, 1, 0);
        inputPane.add(password, 0, 1);
        inputPane.add(pwInput, 1, 1);
        inputPane.setAlignment(Pos.CENTER);
        HBox buttonPane = new HBox();
        buttonPane.getChildren().addAll(quit, enter);
        buttonPane.setSpacing(125);
        buttonPane.setAlignment(Pos.CENTER);
        inputPane.add(buttonPane, 1, 3);
        //create VBox to arrange all items
        VBox mainPane = new VBox();
        mainPane.setSpacing(20);
        mainPane.getChildren().addAll(title, intro, inputPane);
        //set VBox background to black and center the position
        mainPane.setStyle("-fx-background-color: black");
        mainPane.setAlignment(Pos.CENTER);
        //create scene and input the pane
        scene = new Scene(mainPane, 700, 700);
        primaryStage.setScene(scene);
        //show the scene
        primaryStage.show();
    }
}


