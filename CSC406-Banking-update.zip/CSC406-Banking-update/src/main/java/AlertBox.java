import java.util.List;

import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import database.Account.AccountEntity;
import database.Account.AccountQuery;
import javafx.collections.ObservableList;

//How to use this:
//AlertBox.display("title","message",account type as integer);
public class AlertBox extends overView {
    String TypesOfaccount;

    public void display(String title, String message, int accountType, ObservableList<database> customer) {
        if (accountType == 1) {
            TypesOfaccount = "Checking";
        } else if (accountType == 2) {
            TypesOfaccount = "Savings";
        } else if (accountType == 3) {
            TypesOfaccount = "Credit";
        } else {
            TypesOfaccount = "Loan";
        }
        Stage window = new Stage();
        String ssn = customer.get(0).getSSN();
        List<AccountEntity> acc = new AccountQuery().getBySSN(ssn).execute();
        ObservableList<AccountEntity> storeCus = FXCollections.observableArrayList();
        for (int i = 0; i < acc.size(); i++) {
            if (acc.get(i).getTYPE().equals(TypesOfaccount)) {
                storeCus.add(acc.get(i));
            }
        }


        String Accbalance = String.valueOf(storeCus.get(0).getFUTURE_VALUE());
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        //create message text
        Text output = new Text();
        output.setText(message);
        output.setFill(Color.YELLOW);
        output.setFont(Font.font(null, 25));
        Text checkingBalance = new Text("Checking balance: $" + Accbalance);
        checkingBalance.setFill(Color.WHITE);
        Text savingBalance = new Text("Savings balance: $" + Accbalance);
        savingBalance.setFill(Color.WHITE);
        //text for balance
        Text chBalance = new Text(Accbalance);
        chBalance.setFill(Color.WHITE);
        Text saBalance = new Text(Accbalance);
        saBalance.setFill(Color.WHITE);
        Text creditBalance = new Text("Credit balance: $" + Accbalance);
        creditBalance.setFill(Color.WHITE);
        Text crBalance = new Text(Accbalance);
        crBalance.setFill(Color.WHITE);
        Text loanBalance = new Text("Loan balance: $" + Accbalance);
        loanBalance.setFill(Color.WHITE);
        Text loBalance = new Text(Accbalance);
        loBalance.setFill(Color.WHITE);
        //button for back, home, and quit
        Button close = new Button("Close");
        close.setOnAction(e -> window.close());
        close.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        //create pane
        HBox action = new HBox();
        action.getChildren().addAll(close);
        action.setSpacing(50);
        action.setAlignment(Pos.CENTER);
        GridPane balance = new GridPane();
        Text accountT = new Text();
        Text accountBalance = new Text();
        switch (accountType) {
            case 1:
                accountT = checkingBalance;
                accountBalance = chBalance;
                break;
            case 2:
                accountT = savingBalance;
                accountBalance = saBalance;
                break;
            case 3:
                accountT = creditBalance;
                accountBalance = crBalance;
                break;
            case 4:
                accountT = loanBalance;
                accountBalance = loBalance;
                break;
            default:
                accountT.setText("");
                break;
        }
        accountBalance.setText("");
        balance.add(accountT, 0, 0);
        balance.add(accountBalance, 1, 0);
        balance.setAlignment(Pos.CENTER);
        balance.setHgap(20);
        VBox pane = new VBox(output, balance, action);
        pane.setStyle("-fx-background-color: black");
        pane.setSpacing(20);
        pane.setAlignment(Pos.CENTER);
        Scene scene = new Scene(pane, 500, 200);
        window.setScene(scene);
        //window will not close until you close or hide it
        window.showAndWait();
    }

    public static void display(String title, String message) {
        Stage window = new Stage();

        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        //create message text
        Text output = new Text();
        output.setText(message);
        output.setFill(Color.YELLOW);
        output.setFont(Font.font(null, 25));
        Button close = new Button("Close");
        close.setOnAction(e -> window.close());
        close.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        //create pane
        HBox action = new HBox();
        action.getChildren().addAll(close);
        action.setSpacing(50);
        action.setAlignment(Pos.CENTER);
        VBox pane = new VBox(output, action);
        pane.setStyle("-fx-background-color: black");
        pane.setSpacing(20);
        pane.setAlignment(Pos.CENTER);


        Scene scene = new Scene(pane, 300, 200);
        window.setScene(scene);
        //window will not close until you close or hide it
        window.showAndWait();
    }
}