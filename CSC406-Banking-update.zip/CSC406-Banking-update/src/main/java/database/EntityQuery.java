package database;

public class EntityQuery
{
  public EntityQuery getByID(long id){ return null; }
  public Entity getFirst(){ return null; }
  public EntityQuery getBySSN(String ssn){return null;}
}//end of class EntityQuery
