package database.Check;


import database.Entity;
import database.EntityQuery;

import java.nio.file.NoSuchFileException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


/*
 *   CheckQuery
 *         Supports following calls:
 *
 *     getAll()
 *     getByID(long)
 *     getBySSN(int)
 *     getByCheckNumber(String)
 *     getByDateHonored(String)
 *
 *     calls may be chained
 *           but must be terminated by:
 *
 *                 execute() (returns List<Check>)
 *                    or
 *                 getFirst() (returns first Check or null)
 *
 */
public class CheckQuery extends EntityQuery
{
    //initial query of all entities from Customer.txt
    private List<Check> initialSet;

    //intermediate resultSet (for chaining)
    private List<Check> tempSet;

    //final returned results
    private List<Check> resultSet;

    //true if one or more calls to a getBy function
    //(if chaining has begun)
    private boolean firstCallOccurred;

    public CheckQuery()
    {

        try
        {
            initialSet = Check.parse(Entity.readFromTextFile(new Check().getTextFileName(), new Check().getDelimiter()));
            tempSet = new ArrayList<>();
            resultSet = new ArrayList<>();

            firstCallOccurred = false;
        }catch(NoSuchFieldException | NoSuchFileException | InstantiationException | IllegalAccessException e){ e.printStackTrace(); }
    }

    // Use as chain terminator
    // instead of execute() if only
    // expecting one result.
    public Check getFirst()
    {
        Check singleResult;
        //no result
        if(resultSet.size() < 1) singleResult = null;
        else
        {
            singleResult = resultSet.get(0);
        }
        return singleResult;
    }

    // Use as chain terminator.
    // instead of getFirst if
    // expecting more than one result.
    public List<Check> execute()
    {
        return resultSet;
    }

    //get all accounts, still needs to call execute()
    //only usage:   customerQuery.getAll().execute();
    public CheckQuery getAll()
    {
        resultSet = initialSet;
        return this;
    }

    //filter on ID
    public CheckQuery getByID(long id)
    {
        //if a getBy function was already called
        if(firstCallOccurred)
        {
            //filter resultSet to tempSet
            tempSet = resultSet.stream().filter(a -> a.getID() == id)
                    .collect(Collectors.toList());
            //replace resultSet with tempSet
            resultSet = tempSet;
        }
        else
        {
            //filter on getID() matching id
            resultSet = initialSet.stream().filter(a -> a.getID() == id)
                    .collect(Collectors.toList());
            firstCallOccurred = true;
        }

        return this;
    }

    //filter on SSN
    public CheckQuery getBySSN(String ssn)
    {
        if(firstCallOccurred)
        {
            tempSet = resultSet.stream().filter(a -> a.getSSN().equals(ssn))
                    .collect(Collectors.toList());
            resultSet = tempSet;
        }
        else
        {
            //filter on getSSN() matching ssn
            resultSet = initialSet.stream().filter(a -> a.getSSN().equals(ssn))
                    .collect(Collectors.toList());
            firstCallOccurred = true;
        }
        return this;
    }//end of filter on ssn



    //filter on Check Number
    public CheckQuery getByCheckNumber(String checknum)
    {
        if(firstCallOccurred)
        {
            tempSet = resultSet.stream().filter(a -> a.getCHECK_NUMBER().equals(checknum))
                    .collect(Collectors.toList());
            resultSet = tempSet;
        }
        else
        {
            //filter on getSSN() matching ssn
            resultSet = initialSet.stream().filter(a -> a.getCHECK_NUMBER().equals(checknum))
                    .collect(Collectors.toList());
            firstCallOccurred = true;
        }
        return this;
    }//end of filter on


    //filter on Check Number
    public CheckQuery getByDateHonored(String honordate)
    {
        if(firstCallOccurred)
        {
            tempSet = resultSet.stream().filter(a -> a.getDATE_HONORED().equals(honordate))
                    .collect(Collectors.toList());
            resultSet = tempSet;
        }
        else
        {
            //filter on getSSN() matching ssn
            resultSet = initialSet.stream().filter(a -> a.getDATE_HONORED().equals(honordate))
                    .collect(Collectors.toList());
            firstCallOccurred = true;
        }
        return this;
    }//end of filter on

}//end of class AccountQuery
