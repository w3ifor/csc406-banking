package database.Check;

import database.Entity;
import database.EntityQuery;
import database.FieldNameTypeAndValue;

import java.nio.file.NoSuchFileException;
import java.util.ArrayList;

public class Check extends Entity
{

    //member variables order matters
    //must be the same order as toTextFileString()'s
    //local variable
    private long   ID;
    private String SSN;
    private String CHECK_NUMBER;
    private String RECIPIENT;
    private String AMOUNT;
    private String DATE_WRITTEN;
    private String DATE_HONORED;


    public Check(){}

    public Check(String SSN, String CHECK_NUMBER, String RECIPIENT,
                 String AMOUNT, String DATE_WRITTEN, String DATE_HONORED)
    {
        this.SSN = SSN;
        this.CHECK_NUMBER = CHECK_NUMBER;
        this.RECIPIENT = RECIPIENT;
        this.AMOUNT = AMOUNT;
        this.DATE_WRITTEN = DATE_WRITTEN;
        this.DATE_HONORED = DATE_HONORED;

        this.ID = toString().hashCode();

    }//end of (business logic) AccountEntity constructor
    public Check(String CHECK_NUMBER, String RECIPIENT,
                 String AMOUNT, String DATE_WRITTEN, String DATE_HONORED)
    {
        this.CHECK_NUMBER = CHECK_NUMBER;
        this.RECIPIENT = RECIPIENT;
        this.AMOUNT = AMOUNT;
        this.DATE_WRITTEN = DATE_WRITTEN;
        this.DATE_HONORED = DATE_HONORED;

    }//end of (business logic) AccountEntity constructor
    //parsing constructor (when constructing objects from parsed text file)
    public Check(long ID, String SSN, String CHECK_NUMBER, String RECIPIENT,
                 String AMOUNT, String DATE_WRITTEN, String DATE_HONORED)
    {
        this.ID = ID;
        this.SSN = SSN;
        this.CHECK_NUMBER = CHECK_NUMBER;
        this.RECIPIENT = RECIPIENT;
        this.AMOUNT = AMOUNT;
        this.DATE_WRITTEN = DATE_WRITTEN;
        this.DATE_HONORED = DATE_HONORED;


    }//end of parsing AccountEntity constructor


    //takes an arraylist of each stringified (delimited) entity and casts each to a Check
    public static ArrayList<Check> parse(ArrayList<String> preparsedRecords) throws NoSuchFileException,NoSuchFieldException,InstantiationException,IllegalAccessException
    {
        //returned list of checks
        ArrayList<Check> checksFromFile = new ArrayList<>();

        ArrayList<String> preparsedFields = new ArrayList<String>();
        //fields after being parsed
        ArrayList<Object> parsedFields = new ArrayList<Object>();

        for(String account : preparsedRecords)
        {

            for(String field : account.split(new Check().getDelimiter()))
            {
                preparsedFields.add(field);
            }

            //because same order is maintained between
            //fields of AccountEntity class, and text file
            int i = 0;
            //cast each field to its corresponding type
            for(FieldNameTypeAndValue cfield : new Check().getMemberFields())
            {
                if(cfield.getType().equals("long"))
                {
                    parsedFields.add(Long.parseLong(preparsedFields.get(i)));
                }
                else if(cfield.getType().equals("double"))
                {
                    parsedFields.add(Double.parseDouble(preparsedFields.get(i)));
                }
                else if(cfield.getType().equals("int"))
                {
                    parsedFields.add(Integer.parseInt(preparsedFields.get(i)));
                }
                else{  parsedFields.add(preparsedFields.get(i)); }//its a String
                i += 1;
            }//end for loop

            Check parsedCheck = new Check((long)parsedFields.get(0), //ID
                    (String)parsedFields.get(1),//SSN
                    (String)parsedFields.get(2),//CHECK_NUMBER
                    (String)parsedFields.get(3),//RECIPIENT
                    (String)parsedFields.get(4),//AMOUNT
                    (String)parsedFields.get(5),//DATE_WRITTEN
                    (String)parsedFields.get(6));//DATE_HONORED

            checksFromFile.add(parsedCheck);

            //clear for next line input
            parsedFields.clear();
            preparsedFields.clear();
        }//end of for


        return checksFromFile;
    }//end of parse()



    /*
     *  AccountEntity inherits query() from Entity.
     * Needs implementation to call this instead of Entity.query().
     */
    public EntityQuery query()
    {
        return new CheckQuery();
    }//end of query

    //these won't change, and we don't want them getting returned with other fields
    //from calls to getFields()
    public String getTextFileName(){ return "./db/Check/Check.txt"; }
    public String getBackupTextFileName(){ return "./db/Check/OLD_Check.txt"; }
    public String getDelimiter(){ return ", "; }

    public long   getID(){ return ID; }
    public String getSSN(){ return SSN; }
    public String getCHECK_NUMBER(){ return CHECK_NUMBER; }
    public String getRECIPIENT(){ return RECIPIENT; }
    public String getAMOUNT(){ return AMOUNT; }
    public String getDATE_WRITTEN(){ return DATE_WRITTEN; }
    public String getDATE_HONORED(){ return DATE_HONORED; }

    public void   setDATE_HONORED(String date){ DATE_HONORED = date; }
}