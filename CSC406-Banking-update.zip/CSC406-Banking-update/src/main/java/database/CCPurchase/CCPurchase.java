package database.CCPurchase;

import database.Entity;
import database.EntityQuery;
import database.FieldNameTypeAndValue;

import java.nio.file.NoSuchFileException;
import java.util.ArrayList;

//Credit Card Purchase
public class CCPurchase extends Entity
{

    //member variables order matters
    //must be the same order as toTextFileString()'s
    //local variable
    private long   ID;
    private String SSN;
    private String DESCRIPTION;
    private double AMOUNT;
    private String DATE;

    public CCPurchase(){}

    public CCPurchase(String SSN, String DESCRIPTION, double AMOUNT, String DATE)
    {
        this.SSN = SSN;
        this.DESCRIPTION = DESCRIPTION;
        this.AMOUNT = AMOUNT;
        this.DATE = DATE;

        this.ID = toString().hashCode();

    }//end of (business logic) AccountEntity constructor

    //parsing constructor (when constructing objects from parsed text file)
    public CCPurchase(long ID, String SSN, String DESCRIPTION, double AMOUNT, String DATE)
    {
        this.ID = ID;
        this.SSN = SSN;
        this.DESCRIPTION = DESCRIPTION;
        this.AMOUNT = AMOUNT;
        this.DATE = DATE;

    }//end of parsing AccountEntity constructor

    public CCPurchase(long ID, String DESCRIPTION, double AMOUNT, String DATE)
    {
        this.ID = ID;
        this.DESCRIPTION = DESCRIPTION;
        this.AMOUNT = AMOUNT;
        this.DATE = DATE;

    }//end of parsing AccountEntity constructor



    //takes an arraylist of each stringified (delimited) entity and casts each to an CCPurchase
    public static ArrayList<CCPurchase> parse(ArrayList<String> preparsedRecords) throws NoSuchFileException,NoSuchFieldException,InstantiationException,IllegalAccessException
    {
        //returned list of accounts
        ArrayList<CCPurchase> purchasesFromFile = new ArrayList<>();

        ArrayList<String> preparsedFields = new ArrayList<String>();
        //fields after being parsed
        ArrayList<Object> parsedFields = new ArrayList<Object>();

        for(String ccpurchase : preparsedRecords)
        {

            for(String field : ccpurchase.split(new CCPurchase().getDelimiter()))
            {
                preparsedFields.add(field);
            }

            //because same order is maintained between
            //fields of CCPurchase class, and text file
            int i = 0;
            //cast each field to its corresponding type
            for(FieldNameTypeAndValue cfield : new CCPurchase().getMemberFields())
            {
                if(cfield.getType().equals("long"))
                {
                    parsedFields.add(Long.parseLong(preparsedFields.get(i)));
                }
                else if(cfield.getType().equals("double"))
                {
                    parsedFields.add(Double.parseDouble(preparsedFields.get(i)));
                }
                else if(cfield.getType().equals("int"))
                {
                    parsedFields.add(Integer.parseInt(preparsedFields.get(i)));
                }
                else{  parsedFields.add(preparsedFields.get(i)); }//its a String
                i += 1;
            }//end for loop


            CCPurchase parsedPurchase = new CCPurchase((long)parsedFields.get(0), //ID
                                                       (String)parsedFields.get(1),//SSN
                                                       (String)parsedFields.get(2),//DESCRIPTION
                                                       (double)parsedFields.get(3),//AMOUNT
                                                       (String)parsedFields.get(4));//DATE


            purchasesFromFile.add(parsedPurchase);
            //clear for next line input
            parsedFields.clear();
            preparsedFields.clear();
        }//end of for
        return purchasesFromFile;
    }//end of parse()



    /*
     *  CCPurchase inherits query() from Entity.
     * Needs implementation to call this instead of Entity.query().
     */
    public EntityQuery query()
    {
        return new CCPurchaseQuery();
    }//end of query

    //these won't change, and we don't want them getting returned with other fields
    //from calls to getFields()
    public String getTextFileName(){ return "./db/CCPurchase/CCPurchase.txt"; }
    public String getBackupTextFileName(){ return "./db/CCPurchase/OLD_CCPurchase.txt"; }
    public String getDelimiter(){ return ", "; }

    public long   getID(){ return ID; }
    public String getSSN(){ return SSN; }
    public String getDESCRIPTION(){ return DESCRIPTION; }
    public double getAMOUNT(){ return AMOUNT; }
    public String getDATE(){ return DATE; }

}
