package database.CCPurchase;


import database.Entity;
import database.EntityQuery;

import java.nio.file.NoSuchFileException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


/*
 *   CustomerQuery
 *         Supports following calls:
 *
 *     getAll()
 *     getByID(long)
 *     getBySSN(int)
 *     getByType(String)
 *     getBySubType(String)
 *
 *     calls may be chained
 *           but must be terminated by:
 *
 *                 execute() (returns List<AccountEntity>)
 *                    or
 *                 getFirst() (returns first AccountEntity or null)
 *
 */
public class CCPurchaseQuery extends EntityQuery
{
    //initial query of all entities from Customer.txt
    private List<CCPurchase> initialSet;

    //intermediate resultSet (for chaining)
    private List<CCPurchase> tempSet;

    //final returned results
    private List<CCPurchase> resultSet;

    //true if one or more calls to a getBy function
    //(if chaining has begun)
    private boolean firstCallOccurred;

    public CCPurchaseQuery()
    {

        try
        {
            initialSet = CCPurchase.parse(Entity.readFromTextFile(new CCPurchase().getTextFileName(), new CCPurchase().getDelimiter()));
            tempSet = new ArrayList<>();
            resultSet = new ArrayList<>();

            firstCallOccurred = false;
        }catch(NoSuchFieldException | NoSuchFileException | InstantiationException | IllegalAccessException e){ e.printStackTrace(); }
    }

    // Use as chain terminator
    // instead of execute() if only
    // expecting one result.
    public CCPurchase getFirst()
    {
        CCPurchase singleResult;
        //no result
        if(resultSet.size() < 1) singleResult = null;
        else
        {
            singleResult = resultSet.get(0);
        }
        return singleResult;
    }

    // Use as chain terminator.
    // instead of getFirst if
    // expecting more than one result.
    public List<CCPurchase> execute()
    {
        return resultSet;
    }

    //get all accounts, still needs to call execute()
    //only usage:   customerQuery.getAll().execute();
    public CCPurchaseQuery getAll()
    {
        resultSet = initialSet;
        return this;
    }

    //filter on ID
    public CCPurchaseQuery getByID(long id)
    {
        //if a getBy function was already called
        if(firstCallOccurred)
        {
            //filter resultSet to tempSet
            tempSet = resultSet.stream().filter(a -> a.getID() == id)
                    .collect(Collectors.toList());
            //replace resultSet with tempSet
            resultSet = tempSet;
        }
        else
        {
            //filter on getID() matching id
            resultSet = initialSet.stream().filter(a -> a.getID() == id)
                    .collect(Collectors.toList());
            firstCallOccurred = true;
        }

        return this;
    }

    //filter on SSN
    public CCPurchaseQuery getBySSN(String ssn)
    {
        if(firstCallOccurred)
        {
            tempSet = resultSet.stream().filter(a -> a.getSSN().equals(ssn))
                    .collect(Collectors.toList());
            resultSet = tempSet;
        }
        else
        {
            //filter on getSSN() matching ssn
            resultSet = initialSet.stream().filter(a -> a.getSSN().equals(ssn))
                    .collect(Collectors.toList());
            firstCallOccurred = true;
        }
        return this;
    }

}//end of class AccountQuery
