import Accounts.Account;
import database.Account.AccountEntity;
import database.Account.AccountQuery;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class CreateNewAccount extends overView {
    //creating individual account (checking, saving...)
    String initBalance;
    double balance;

    boolean isStudent = false;
    boolean overDraftProtect = false;
    int termPeriod = 0;
    double IR = 0.0;
    String level = "";

    //value parameter is for indication of which account you want to create: 1=checking, 2=saving, 3=credit card, 4=loan, 5=CD
    public void display(Stage primaryStage, ObservableList<database> customer, int value) {
        //setting the font and size of the texts
        Text howMuch = new Text();
        howMuch.setFill(Color.WHITE);
        howMuch.setFont(Font.font(null, 20));
        Text message = new Text();
        message.setStyle("-fx-fill: yellow");
        message.setFont(Font.font(null, FontWeight.BOLD, 20));
        //textfield for the amount of deposit, credit, or loan
        TextField amount = new TextField("");
        amount.setPrefColumnCount(10);

        //textfield for the interest rate input
        TextField interestRate = new TextField("");
        interestRate.setPrefColumnCount(10);
        Text interest = new Text("Interest rate:");
        interest.setStyle("-fx-fill: white");
        interest.setFont(Font.font(null, 20));
        Text term = new Text("Term Period:");
        term.setStyle("-fx-fill: white");
        term.setFont(Font.font(null, 20));
        //checkbox for student
        CheckBox student = new CheckBox("Student");
        student.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        //checkbox for overdraft protect
        CheckBox overDraftP = new CheckBox("Over Draft Protect");
        overDraftP.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        CheckBox longTerm = new CheckBox("Long Term");
        longTerm.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        CheckBox shortTerm = new CheckBox("Short Term");
        shortTerm.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        //textfield for the term amount for loan
        TextField termInput = new TextField("");
        interestRate.setPrefColumnCount(10);
        //quit button will go back tog in page
        Button quit = new Button("Quit");
        quit.setOnAction(e -> {
            try {
                start(primaryStage);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        quit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        //back button will go back to overview page
        Button back = new Button("Back");
        back.setOnAction(e -> {
            overViewAcc = new overView();
            overViewAcc.display(primaryStage, customer);
        });
        back.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        //will not create account unless create button is pressed first
        Button create = new Button("Create");
        create.setOnAction(e -> {
            if (value == 1||value==2) {
                isStudent = student.isSelected();
                overDraftProtect = overDraftP.isSelected();
            } else if(value==4||value==5) {
                termPeriod = Integer.parseInt(termInput.getText());
                IR = Double.parseDouble(interestRate.getText());
            }else{
                IR = Double.parseDouble(interestRate.getText());
            }
            initBalance = amount.getText();
            createNewAccount(customer, value);
            overViewAcc = new overView();
            overViewAcc.display(primaryStage, customer);

        });
        create.setStyle("-fx-background-color: yellow; -fx-text-fill: black");


        //create the panes
        HBox buttons = new HBox();
        buttons.getChildren().addAll(quit, create, back);
        buttons.setAlignment(Pos.CENTER);
        buttons.setSpacing(25);
        GridPane content = new GridPane();
        content.setAlignment(Pos.CENTER);
        content.add(amount, 1, 0);
        content.add(howMuch, 0, 0);
        if (value == 1) {
            content.add(student, 0, 1);
            content.add(overDraftP, 0, 2);
        }
        content.setHgap(15);
        content.setVgap(10);
        VBox pane = new VBox();
        pane.getChildren().addAll(message, content, buttons);
        pane.setAlignment(Pos.CENTER);
        pane.setStyle("-fx-background-color: black");
        pane.setSpacing(50);

        //setting of the value will indicate what account you want to create
        if (value == 1) {
            message.setText("Checking account is not created, would you like to create one?");
            howMuch.setText("How much do you want to deposit?");
        } else if (value == 2) {
            message.setText("Saving account is not created, would you like to create one?");
            howMuch.setText("How much do you want to deposit?");
        } else if (value == 3) {
            message.setText("Credit card account is not created, would you like to create one?");
            howMuch.setText("What is the credit limit?");
            if (manager) {
                content.add(interest, 0, 1);
                content.add(interestRate, 1, 1);
            }
        } else if (value == 4) {
            message.setText("Loan account is not created, would you like to create one?");
            howMuch.setText("How much loan?");
            if (manager) {
                content.add(interest, 0, 1);
                content.add(interestRate, 1, 1);
                content.add(term, 0, 2);
                content.add(termInput, 1, 2);
            }
        } else {
            message.setText("CD account is not created, would you like to create one?");
            howMuch.setText("How much do you want to deposit?");
            content.add(interest, 0, 1);
            content.add(interestRate, 1, 1);
            content.add(term, 0, 2);
            content.add(termInput, 1, 2);

        }

        Scene scene = new Scene(pane, 700, 700);
        primaryStage.setScene(scene);
    }

    //create different type of accounts
    public void createNewAccount(ObservableList<database> customer, int accType) {
        String ssn = customer.get(0).getSSN();
        balance = Double.parseDouble(initBalance);
        String subtype = "";
        String overDP = "";
        String currentDate = "";
        double minPay = calculateInterestDollarAmount(balance, 5, IR);
        //get today's date
        Date date = new Date();
        String DATE_FORMAT = "MM/dd/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        currentDate = sdf.format(date);
        //decided which account needs to be created
        switch (accType) {
            case 1:
                subtype = "Checking";
                IR = 0.0;
                minPay = 0.0;
                break;
            case 2:
                subtype = "Savings";
                minPay = 0.0;
                break;
            case 3:
                subtype = "Credit";
                IR = 0.15;
                break;
            case 4:
                subtype = "Loan";
                break;
            case 5:
                subtype = "CD";
                break;
            default:
                subtype = "";
        }
        if (overDraftProtect == true) {
            overDP = "ON";
        } else {
            overDP = "OFF";
        }
        //first decide which type you want to create by using switch cases
        switch (accType) {
            case 1:
                if (balance < 1000) {
                    level = "Gold";
                } else if (isStudent == true) {
                    level = "Student";
                } else if (balance >= 1000) {
                    level = "Platinum";
                } else {
                    alertbox = new AlertBox();
                    alertbox.display("Error", "Something Wrong");
                }
                AccountEntity newCheckingAccount = new AccountEntity(ssn, balance, subtype, level, overDP, -123456789, currentDate, IR, minPay, null, balance,0);
                newCheckingAccount.add();
                break;
            case 2:
                if (balance < 1000) {
                    level = "Gold";
                    IR = 0.01;
                } else if (balance >= 1000) {
                    level = "Platinum";
                    IR = 0.065;
                } else {
                    alertbox = new AlertBox();
                    alertbox.display("Error", "Something Wrong");
                }
                AccountEntity newSavingsAccount = new AccountEntity(ssn, balance, subtype, level, overDP, -123456789, currentDate, IR, minPay, null, 0.0,termPeriod);
                newSavingsAccount.add();
                break;
            case 3:
                if (balance <= 10000) {
                    AccountEntity newCCAccount = new AccountEntity(ssn, balance, subtype, level, overDP, -123456789, currentDate, IR, minPay, null, 0.0,0);
                    newCCAccount.add();
                } else {
                    alertbox = new AlertBox();
                    alertbox.display("Error", "Over Limit");
                }
                break;
            case 4:
                if (termPeriod > 5&&termPeriod<=15) {
                    level = "Long Term";
                    AccountEntity newLoanAccount = new AccountEntity(ssn, balance, subtype, level, overDP, -123456789, currentDate, IR, minPay, null, 0.0,termPeriod);
                    newLoanAccount.add();
                } else if (termPeriod <= 5) {
                    level = "Short Term";
                    AccountEntity newLoanAccount = new AccountEntity(ssn, balance, subtype, level, overDP, -123456789, currentDate, IR, minPay, null, 0.0,termPeriod);
                    newLoanAccount.add();
                } else {
                    alertbox = new AlertBox();
                    alertbox.display("Error", "Sorry,will not be able to do that");
                    break;
                }
            case 5:
                AccountEntity newCDAccount = new AccountEntity(ssn, balance, subtype, level, overDP, -123456789, currentDate, IR, minPay, null, 0.0,termPeriod);
                newCDAccount.add();
        }
    }

    //calculate the min monthly payment
    public double calculateInterestDollarAmount(double balance, int lengthInYears, double interestRate) {

        double minPay = (balance / (lengthInYears * 12)) + ((balance / 2) * lengthInYears * interestRate) / (lengthInYears * 12);
        return minPay;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }
}