package Accounts;

public class PlatinumSavingsAccount extends DebitAccount {

    public PlatinumSavingsAccount() {

    }

}
