package Accounts;

public class PlatinumCheckingAccount extends Checking {


    public PlatinumCheckingAccount() {

    }

}
