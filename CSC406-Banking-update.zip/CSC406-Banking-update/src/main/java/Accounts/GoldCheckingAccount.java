package Accounts;

public class GoldCheckingAccount extends Checking {

    public GoldCheckingAccount() {

    }

}
