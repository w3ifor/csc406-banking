package Accounts;

public class GoldSavingsAccount extends DebitAccount {

    public GoldSavingsAccount() {

    }

}
