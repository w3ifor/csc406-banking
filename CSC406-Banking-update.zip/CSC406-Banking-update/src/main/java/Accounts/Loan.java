package Accounts;

/**
 * Parent class for all loan accounts
 */
public class Loan extends Account {



}
