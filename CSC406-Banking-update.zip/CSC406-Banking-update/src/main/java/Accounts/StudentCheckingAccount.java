package Accounts;

public class StudentCheckingAccount extends Checking {

    public int studentID;

    public StudentCheckingAccount(int studentID) {
        this.studentID = studentID;
    }


}
