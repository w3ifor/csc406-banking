import database.Account.AccountEntity;
import database.Account.AccountQuery;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CD extends overView{
    double futureAmount;
    public void display(Stage primaryStage, ObservableList<database> customer) {
        String FirstName = customer.get(0).getFname();
        String LastName = customer.get(0).getLname();
        String ssn = customer.get(0).getSSN();

        List<AccountEntity> acc = new AccountQuery().getBySSN(ssn).getByType("CD").execute();
        double Balance = acc.get(0).getBALANCE();
        String level=acc.get(0).getSUBTYPE();
        //customerFound.getBySSN(ssn).execute();
        //name label
        Label greeting = new Label("Hello, ");
        Label Fname = new Label(FirstName);
        Label Lname = new Label(" " + LastName);
        greeting.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Fname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Lname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        //title:checking
        Label title = new Label("CD Account");
        title.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");

        Label accLevel=new Label("Account Level: "+level);
        accLevel.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");

        Label intersetRate=new Label("intersetRate: "+acc.get(0).getINTEREST_RATE());
        intersetRate.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        //account overview: balance
        Text overview = new Text("Inital Balance:");
        overview.setFont(Font.font(null, 20));
        overview.setFill(Color.WHITE);
        Text dateCreated=new Text("Date Created: "+acc.get(0).getDATE_CREATED());
        dateCreated.setFont(Font.font(null, 20));
        dateCreated.setFill(Color.WHITE);

        //comment out after create a account
        futureAmount=futureAmount(acc);
        acc.get(0).setFUTURE_VALUE(futureAmount);
        acc.get(0).update();
        Text balance = new Text("$" + Balance);
        balance.setTextAlignment(TextAlignment.LEFT);
        balance.setFont(Font.font(null, 20));
        balance.setFill(Color.WHITE);
        Text futureBalance=new Text("Amount :"+acc.get(0).getFUTURE_VALUE());
        futureBalance.setTextAlignment(TextAlignment.LEFT);
        futureBalance.setFont(Font.font(null, 20));
        futureBalance.setFill(Color.WHITE);
        LocalDate dateCanGainAllMoney = LocalDate.parse(acc.get(0).getDATE_CREATED(), DateTimeFormatter.ofPattern("MM/dd/uuuu")).plusYears(acc.get(0).getTERM_PERIOD());
        dateCanGainAllMoney.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        Text dateGetAmount=new Text("Date get all money:"+dateCanGainAllMoney.toString());
        dateGetAmount.setTextAlignment(TextAlignment.LEFT);
        dateGetAmount.setFont(Font.font(null, 20));
        dateGetAmount.setFill(Color.WHITE);
        //buttons for home, quite, and transfer money
        Button home = new Button("Home");
        //home button will go back to the overview page
        home.setOnAction(e -> {
            overViewAcc = new overView();
            overViewAcc.display(primaryStage, customer);
        });
        home.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button quit = new Button("Quit");
        quit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    start(primaryStage);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        quit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");

        //create pane
        HBox action2 = new HBox();
        action2.getChildren().addAll(quit, home);
        action2.setSpacing(50);
        action2.setAlignment(Pos.CENTER);
        GridPane accBalance = new GridPane();
        accBalance.add(overview, 0, 0);
        accBalance.add(balance, 1, 0);
        accBalance.setHgap(25);
        accBalance.setAlignment(Pos.CENTER);
        GridPane name = new GridPane();
        name.add(greeting, 0, 0);
        name.add(Fname, 1, 0);
        name.add(Lname, 2, 0);
        name.setAlignment(Pos.CENTER);
        VBox pane = new VBox();
        if (teller || manager) {
            pane.getChildren().addAll(name, title,intersetRate,dateCreated, accBalance,dateGetAmount,futureBalance, action2);
        } else {
            pane.getChildren().addAll(name, title,intersetRate,dateCreated,accBalance, dateGetAmount,futureBalance,action2);
        }
        pane.setStyle("-fx-background-color: black");
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(20);
        scene = new Scene(pane, 700, 700);
        primaryStage.setScene(scene);
    }

public double futureAmount(List<AccountEntity> acc){
    double amount=acc.get(0).getBALANCE() * (Math.pow((1.0 + acc.get(0).getINTEREST_RATE()/365.0), (acc.get(0).getTERM_PERIOD()*365.0)));
    return amount;
}
}

