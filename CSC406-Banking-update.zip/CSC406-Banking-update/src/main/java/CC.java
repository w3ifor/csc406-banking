import database.Account.AccountEntity;
import database.Account.AccountQuery;
import database.CCPurchase.CCPurchase;
import database.CCPurchase.CCPurchaseQuery;
import database.Check.Check;
import database.Check.CheckQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;

import javax.swing.text.Document;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CC extends overView {
    double minPay;
    String dueDate;
    double Credit_Limit;
    TableView<CCPurchase> PurchasesTable;
    double Payment = 0.0;
    double totalPurchase = 0.0;
    Text OVBalance, currentBalance;

    public void display(Stage primaryStage, ObservableList<database> customer) {
        //name label
        String FirstName = customer.get(0).getFname();
        String LastName = customer.get(0).getLname();
        String ssn = customer.get(0).getSSN();
        //find the matching ssn
        List<AccountEntity> acc = new AccountQuery().getBySSN(ssn).getByType("Credit").execute();
        dueDate = acc.get(0).getDATE_NEXT_PAYMENT_DUE();
        Credit_Limit = acc.get(0).getBALANCE();
        totalPurchase = calculateTotal(ssn);
        //basic oouput customer info
        Label greeting = new Label("Hello, ");
        Label Fname = new Label(FirstName);
        Label Lname = new Label(" " + LastName);
        greeting.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Fname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Lname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        //title:checking
        Label title = new Label("Credit Card");
        title.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 25");
        //Payment Due Date
        Text dueD = new Text("Last Payment:");
        dueD.setFont(Font.font(null, 20));
        dueD.setFill(Color.WHITE);
        Text dueday = new Text(dueDate);
        dueday.setFont(Font.font(null, 20));
        dueday.setFill(Color.WHITE);
        //Minimum Payment
        Text MinP = new Text("Minimum Payment:");
        MinP.setFont(Font.font(null, 20));
        MinP.setFill(Color.WHITE);
        //account overview: balance
        Text balanceOA = new Text("Available/Limit:");
        balanceOA.setFont(Font.font(null, 20));
        balanceOA.setFill(Color.WHITE);
        OVBalance = new Text(String.valueOf(Credit_Limit - acc.get(0).getFUTURE_VALUE()) + "/" + String.valueOf(Credit_Limit));
        OVBalance.setTextAlignment(TextAlignment.LEFT);
        OVBalance.setFont(Font.font(null, 20));
        OVBalance.setFill(Color.WHITE);
        Text interestR = new Text("APR:");
        interestR.setFont(Font.font(null, 20));
        interestR.setFill(Color.WHITE);
        Text interestRate = new Text(String.valueOf(acc.get(0).getINTEREST_RATE()));
        interestRate.setTextAlignment(TextAlignment.LEFT);
        interestRate.setFont(Font.font(null, 20));
        interestRate.setFill(Color.WHITE);
        //edit interest rate
        Label update = new Label("Update APR: ");
        update.setStyle("-fx-text-fill: red; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        TextField updateIR = new TextField();
        updateIR.setPrefWidth(50);
        Text MinPayment = new Text(String.valueOf(minPayment(acc)));
        MinPayment.setFont(Font.font(null, 20));
        MinPayment.setFill(Color.WHITE);
        minPay = minPayment(acc);
        acc.get(0).setMINIMUM_PAYMENT(minPay);
        acc.get(0).update();
        //create a table view for CC purchases
        TableColumn<CCPurchase, Long> ID = new TableColumn<>("ID");
        ID.setPrefWidth(125);
        ID.setCellValueFactory(new PropertyValueFactory<>("ID"));

        TableColumn<CCPurchase, String> DESCRIPTION = new TableColumn<>("DESCRIPTION");
        DESCRIPTION.setPrefWidth(125);
        DESCRIPTION.setCellValueFactory(new PropertyValueFactory<>("DESCRIPTION"));

        TableColumn<CCPurchase, Double> AMOUNT = new TableColumn<>("AMOUNT");
        AMOUNT.setPrefWidth(125);
        AMOUNT.setCellValueFactory(new PropertyValueFactory<>("AMOUNT"));

        TableColumn<CCPurchase, String> DATE = new TableColumn<>("DATE");
        DATE.setPrefWidth(125);
        DATE.setCellValueFactory(new PropertyValueFactory<>("DATE"));

        PurchasesTable = new TableView<>();
        PurchasesTable.getColumns().addAll(ID, DESCRIPTION, AMOUNT, DATE);
        PurchasesTable.setEditable(false);
        displayAllPurchases(acc.get(0).getSSN(), PurchasesTable);

        Label des = new Label("Description");
        Label amount = new Label("Amount");
        Label date = new Label("Date(MM/dd/yyyy)");
        TextField desInput = new TextField();
        TextField amountInput = new TextField();
        TextField dateInput = new TextField();
        Button addCharge = new Button("Add");
        addCharge.setStyle("-fx-background-color: white; -fx-text-fill: black");
        addCharge.setOnAction(e -> {
            if (desInput.getText() == null || amountInput.getText() == null || dateInput.getText() == null) {
                alertbox.display("Invalid input", "Invalid input");
            } else {
                CCPurchase newCCpucchase = new CCPurchase(ssn, desInput.getText(), Double.parseDouble(amountInput.getText()), dateInput.getText());
                addDatatoDatabase(newCCpucchase, acc);
                desInput.clear();
                amountInput.clear();
                dateInput.clear();
                newCCpucchase.update();
                displayAllPurchases(ssn, PurchasesTable);
            }
        });
        des.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        amount.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        date.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");


        GridPane addCharges = new GridPane();
        addCharges.add(des, 0, 0);
        addCharges.add(amount, 1, 0);
        addCharges.add(date, 2, 0);
        addCharges.add(desInput, 0, 1);
        addCharges.add(amountInput, 1, 1);
        addCharges.add(dateInput, 2, 1);
        addCharges.add(addCharge, 1, 2);
        addCharges.setHgap(25);
        addCharges.setVgap(10);
        addCharges.setAlignment(Pos.CENTER);
        ScrollPane hisBox = new ScrollPane();
        hisBox.setContent(PurchasesTable);
        hisBox.setFitToWidth(true);
        hisBox.setPrefWidth(450);
        hisBox.setPrefHeight(200);

        Label paymenttitle = new Label("Make a Payment");
        paymenttitle.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 25");
        Text setPDate = new Text("Set Payment Date:");
        setPDate.setFont(Font.font(null, 20));
        setPDate.setFill(Color.WHITE);
        DatePicker dateP = new DatePicker();
        LocalDate localDate = dateP.getValue();
        ToggleGroup RadioBGroup = new ToggleGroup();
        RadioButton CurrentB = new RadioButton("Current Balance :");
        CurrentB.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        currentBalance = new Text(String.valueOf(acc.get(0).getFUTURE_VALUE()));
        currentBalance.setFont(Font.font(null, 20));
        currentBalance.setFill(Color.WHITE);
        CurrentB.setToggleGroup(RadioBGroup);
        RadioButton MinB = new RadioButton("Minimun Balance :");
        MinB.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        Text MinBalance = new Text(String.valueOf(acc.get(0).getMINIMUM_PAYMENT()));
        MinBalance.setFont(Font.font(null, 20));
        MinBalance.setFill(Color.WHITE);
        CurrentB.setToggleGroup(RadioBGroup);
        MinB.setToggleGroup(RadioBGroup);
        RadioButton other = new RadioButton("Other:");
        other.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        TextField payAmount = new TextField();
        payAmount.setPrefWidth(120);
        other.setToggleGroup(RadioBGroup);
        GridPane setPaymentdate = new GridPane();
        setPaymentdate.add(setPDate, 0, 0);
        setPaymentdate.add(dateP, 1, 0);
        setPaymentdate.setHgap(25);
        setPaymentdate.setAlignment(Pos.CENTER);
        GridPane pOptions = new GridPane();
        pOptions.add(CurrentB, 0, 0);
        pOptions.add(currentBalance, 1, 0);
        pOptions.add(MinB, 0, 1);
        pOptions.add(MinBalance, 1, 1);
        pOptions.add(other, 0, 2);
        pOptions.add(payAmount, 1, 2);
        pOptions.setVgap(20);
        pOptions.setAlignment(Pos.CENTER);
        //button for making a payment
        Button makePayment = new Button("Pay");
        dateP.setOnAction(e -> {
            dueDate = dateP.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        });
        makePayment.setOnAction(e -> {
            if (CurrentB.isSelected()) {
                Payment = acc.get(0).getFUTURE_VALUE();
                OVBalance.setText(String.valueOf(Credit_Limit - acc.get(0).getFUTURE_VALUE() + Payment) + "/" + String.valueOf(Credit_Limit));
                acc.get(0).setFUTURE_VALUE(0);
                acc.get(0).setDATE_NEXT_PAYMENT_DUE(dueDate);
                dueday.setText(dueDate);
                acc.get(0).update();
                MinPayment.setText(String.valueOf(minPayment(acc)));
                acc.get(0).setMINIMUM_PAYMENT(minPayment(acc));
                acc.get(0).update();
            } else if (MinB.isSelected()) {
                Payment = acc.get(0).getMINIMUM_PAYMENT();
                OVBalance.setText(String.valueOf(Credit_Limit - acc.get(0).getFUTURE_VALUE() + Payment) + "/" + String.valueOf(Credit_Limit));
                acc.get(0).setFUTURE_VALUE(acc.get(0).getFUTURE_VALUE() - acc.get(0).getMINIMUM_PAYMENT());
                acc.get(0).setDATE_NEXT_PAYMENT_DUE(dueDate);
                dueday.setText(dueDate);
                acc.get(0).update();
                MinPayment.setText(String.valueOf(minPayment(acc)));
                acc.get(0).setMINIMUM_PAYMENT(minPayment(acc));
                acc.get(0).update();
            } else if (other.isSelected()) {
                Payment = Double.parseDouble(payAmount.getText());
                OVBalance.setText(String.valueOf(Credit_Limit - acc.get(0).getFUTURE_VALUE() + Payment) + "/" + String.valueOf(Credit_Limit));
                acc.get(0).setFUTURE_VALUE(acc.get(0).getFUTURE_VALUE() + (Double.parseDouble(payAmount.getText())));
                acc.get(0).setDATE_NEXT_PAYMENT_DUE(dueDate);
                dueday.setText(dueDate);
                acc.get(0).update();
                MinPayment.setText(String.valueOf(minPayment(acc)));
                acc.get(0).setMINIMUM_PAYMENT(minPayment(acc));
                acc.get(0).update();
                // payment=Double.parseDouble(payAmount.getText());
                acc.get(0).update();
            } else {
                AlertBox alertBox = new AlertBox();
                alertBox.display("Warning", "please Select one of above");
            }
            List<AccountEntity> checkingacc = new AccountQuery().getBySSN(ssn).getByType("Checking").execute();
            checkingacc.get(0).setBALANCE(checkingacc.get(0).getBALANCE() - Payment);
            checkingacc.get(0).update();
        });

        //buttons for home, quite, and transfer money
        Button home = new Button("Home");
        home.setOnAction(e -> {
            overViewAcc = new overView();
            overViewAcc.display(primaryStage, customer);
        });
        home.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button quit = new Button("Quit");
        quit.setOnAction(e -> {
            try {
                start(primaryStage);
            } catch (Exception er) {
                er.printStackTrace();
            }
        });
        quit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");

        Button save = new Button("Save");
        save.setOnAction(e -> {
            interestRate.setText(updateIR.getText());
            MinPayment.setText(String.valueOf(minPayment(acc)));
            acc.get(0).setINTEREST_RATE(Double.parseDouble(updateIR.getText()));
            acc.get(0).update();
        });
        save.setStyle("-fx-background-color: blue; -fx-text-fill: black");
        //create pane
        HBox action = new HBox();
        if (teller || manager) action.getChildren().addAll(home, quit, save);
        else action.getChildren().addAll(home, quit);
        action.setSpacing(50);
        action.setAlignment(Pos.CENTER);
        ;//name grid
        GridPane name = new GridPane();
        name.add(greeting, 0, 0);
        name.add(Fname, 1, 0);
        name.add(Lname, 2, 0);
        name.setAlignment(Pos.CENTER);
        //customer payment info
        GridPane info = new GridPane();
        info.add(dueD, 0, 0);
        info.add(dueday, 1, 0);
        info.add(MinP, 0, 1);
        info.add(MinPayment, 1, 1);
        info.add(balanceOA, 0, 2);
        info.add(OVBalance, 1, 2);
        info.add(interestR, 0, 3);
        info.add(interestRate, 1, 3);
        info.setHgap(25);
        info.setVgap(25);
        info.setAlignment(Pos.CENTER);
        GridPane IR = new GridPane();
        IR.add(update, 0, 0);
        IR.add(updateIR, 1, 0);
        IR.setAlignment(Pos.CENTER);
        VBox pane = new VBox();

        if (teller || manager)
            pane.getChildren().addAll(name, title, info, IR, hisBox, addCharges, paymenttitle, setPaymentdate, pOptions, makePayment, action);
        else pane.getChildren().addAll(name, title, info, action);
        pane.setStyle("-fx-background-color: black");
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(20);
        scene = new Scene(pane, 600, 900);
        primaryStage.setScene(scene);
    }

    public double calculateTotal(String ssn) {
        double total = 0;

        List<CCPurchase> purchaseList = new CCPurchaseQuery().getBySSN(ssn).execute();
        for (int i = 0; i < purchaseList.size(); i++) {
            total += purchaseList.get(i).getAMOUNT();
        }
        return total;
    }

    public double minPayment(List<AccountEntity> acc) {
        double balance;
        double min = 0;
        balance = acc.get(0).getFUTURE_VALUE();
        if (balance <= 125) {
            min = 25;
        } else {
            min = balance * 0.2;
        }
        return min;
    }

    public void displayAllPurchases(String ssn, TableView newdata) {
        List<CCPurchase> all = new CCPurchaseQuery().getBySSN(ssn).getAll().execute();
        ObservableList<CCPurchase> foundPurchases = FXCollections.observableArrayList();
        for (int i = 0; i < all.size(); i++) {
            foundPurchases.add(new CCPurchase(all.get(i).getID(), all.get(i).getDESCRIPTION(), all.get(i).getAMOUNT(), all.get(i).getDATE()));
        }
        newdata.setItems(foundPurchases);

        if (ssn.equals("") && all.size() == 0) {
            alertbox.display("Invalid ssn", "Can not find ssn\n Please Enter Again");
        }

    }

    public void addDatatoDatabase(CCPurchase newCCPurchase, List<AccountEntity> acc) {
        //create a new customer if the SSN does not existed
        if (newCCPurchase.add() == true) {
            //alertbox=new AlertBox();
            double newBalance = acc.get(0).getBALANCE() - newCCPurchase.getAMOUNT();
            acc.get(0).setBALANCE(newBalance);
            acc.get(0).setFUTURE_VALUE(acc.get(0).getFUTURE_VALUE() + newCCPurchase.getAMOUNT());
            acc.get(0).update();
            currentBalance.setText(String.valueOf(acc.get(0).getFUTURE_VALUE()));
            OVBalance.setText(String.valueOf(newBalance) + "/" + String.valueOf(Credit_Limit));
            alertbox.display("Successful", "New Check added");
        } else {
            //check to see if there is a duplicate SSN
            //alertbox=new AlertBox();
            alertbox.display("Unsuccessful", "Purchase already existed");
        }
    }
}