
import database.Account.AccountEntity;
import database.Account.AccountQuery;
import database.Customer.Customer;
import database.Customer.CustomerQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import database.Check.Check;
import database.Check.CheckQuery;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static java.util.Calendar.getInstance;

public class checking extends overView {
    TableView<Check> ChecksTable;
    String number;
    Text balance;
    public void display(Stage primaryStage, ObservableList<database> customer) {
        String FirstName = customer.get(0).getFname();
        String LastName = customer.get(0).getLname();
        String ssn = customer.get(0).getSSN();

        List<AccountEntity> acc = new AccountQuery().getBySSN(ssn).getByType("Checking").execute();
        double Balance = acc.get(0).getBALANCE();
        String level=acc.get(0).getSUBTYPE();
        //name label
        Label greeting = new Label("Hello, ");
        Label Fname = new Label(FirstName);
        Label Lname = new Label(" " + LastName);
        greeting.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Fname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        Lname.setStyle("-fx-text-fill: yellow; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        //title:checking
        Label title = new Label("Checking Account");
        title.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 20");
        
        //avvount level
        Label accLevel=new Label("Account Level: "+level);
        accLevel.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        
        //account overview: balance
        Text overview = new Text("Balance:");
        overview.setFont(Font.font(null, 20));
        overview.setFill(Color.WHITE);
        balance = new Text(("$" + Balance));
        balance.setTextAlignment(TextAlignment.LEFT);
        balance.setFont(Font.font(null, 20));
        balance.setFill(Color.WHITE);

        //block of code for checks
        //table view of history of checks that have been cashed
        Text checkHistory = new Text("History of Checks:");
        checkHistory.setFont(Font.font(null, 20));
        checkHistory.setFill(Color.WHITE);
        TableColumn<Check,String> checkNumber = new TableColumn<>("CHECK_NUMBER");
        checkNumber.setPrefWidth(125);
        checkNumber.setCellValueFactory(new PropertyValueFactory<>("CHECK_NUMBER"));

        TableColumn<Check,String> Recipient = new TableColumn<>("RECIPIENT");
        Recipient.setPrefWidth(120);
        Recipient.setCellValueFactory(new PropertyValueFactory<>("RECIPIENT"));

        TableColumn<Check,String> checkAmount = new TableColumn<>("AMOUNT");
        checkAmount.setPrefWidth(100);
        checkAmount.setCellValueFactory(new PropertyValueFactory<>("AMOUNT"));

        TableColumn<Check,String>  Date = new TableColumn<>("DATE_WRITTEN");
        Date.setPrefWidth(160);
        Date.setCellValueFactory(new PropertyValueFactory<>("DATE_WRITTEN"));

        TableColumn<Check,String>  transactDate = new TableColumn<>("DATE_HONORED");
        transactDate.setPrefWidth(175);
        transactDate.setCellValueFactory(new PropertyValueFactory<>("DATE_HONORED"));
        ChecksTable = new TableView<>();
        ChecksTable.getColumns().addAll(checkNumber, Recipient, checkAmount, Date, transactDate);
        ChecksTable.setEditable(false);
        displayAllChecks(acc.get(0).getSSN(),ChecksTable);
        ScrollPane hisBox = new ScrollPane();
        hisBox.setContent(ChecksTable);
        hisBox.setFitToWidth(true);
        hisBox.setPrefWidth(450);
        hisBox.setPrefHeight(200);
        //button to stop check from being cashed out
        Button stop = new Button("Stop Payment");
        stop.setStyle("-fx-background-color: red; -fx-text-color: white");
        stop.setOnAction(e->{
           // if(dayDiff(ChecksTable)<=3){
            stopButtonClicked(ChecksTable,acc);
//            }
//            else{
//                AlertBox alertBox=new AlertBox();
//                alertBox.display("Error","Checked already honered");
//            }
        });
        Text cashCheck = new Text("Honor Check:");
        cashCheck.setFont(Font.font(null, FontWeight.BOLD, 20));
        cashCheck.setFill(Color.RED);
        //fields that have to be filled for check information input
        //button to input new check, check to see if it is one of the check that needs to be stopped, if not, then cash out by subtracting from the checking account balance

        HBox checkAction = new HBox();
        checkAction.getChildren().addAll(stop);
        checkAction.setAlignment(Pos.CENTER);
        checkAction.setSpacing(20);

        //buttons for home, quite, and transfer money
        Button home = new Button("Home");
        //home button will go back to the overview page
        home.setOnAction(e -> {
            overViewAcc = new overView();
            overViewAcc.display(primaryStage, customer);
        });
        home.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button quit = new Button("Quit");
        quit.setOnAction(e -> {
            try {
                start(primaryStage);
            } catch (Exception er) {
                er.printStackTrace();
            }
        });
        quit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button transfer = new Button("Transfer");
        //transfer button will go to the input of amount transferring page
        transfer.setOnAction(e -> {
            transfer newtransfer = new transfer();
            newtransfer.display(primaryStage, customer, 1);
        });
        transfer.setStyle("-fx-background-color: white; -fx-text-fill: black");
        Button deposit = new Button("Deposit");
        //deposit button will lead to deposit amount page
        deposit.setOnAction(e -> {
            depositCash = new deposit();
            depositCash.display(primaryStage, customer, 1);
        });
        deposit.setStyle("-fx-background-color: white; -fx-text-fill: black");
        Button withdraw = new Button("Withdraw");
        //withdraw button will lead to withdraw amount page
        withdraw.setOnAction(e -> {
            withDrawCash = new withDraw();
            withDrawCash.display(primaryStage, customer, 1);
        });
        withdraw.setStyle("-fx-background-color: white; -fx-text-fill: black");
        //Labels for creating a check
        Label cRec=new Label("Recipient");
        cRec.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        Label cAmount=new Label("Amount");
        cAmount.setStyle("-fx-text-fill: white; -fx-text-stroke: white; -fx-font-weight: bold; -fx-font-size: 17");
        TextField recipient=new TextField();
        TextField amount=new TextField();
        Date date =new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        String now=formatter.format(date);
        List<Check> all = new CheckQuery().getBySSN(ssn).getAll().execute();

        if(all.size()==0){
            number="1";
        }else{
            int temp=Integer.parseInt(all.get(all.size()-1).getCHECK_NUMBER());
            number=String.valueOf(temp+1);}
                add = new Button("Add Check");
        add.setOnAction(e -> {
            if (recipient.getText() == null || amount.getText() == null) {
                alertbox.display("Invalid input", "Invalid input");
            } else {
                Check newCheck = new Check(acc.get(0).getSSN(),number,recipient.getText(), amount.getText(),now,honoredDate(now));
                addDataToDatabase(newCheck,acc);
                recipient.clear();
                amount.clear();
                newCheck.update();
                displayAllChecks(ssn,ChecksTable);
            }});
        //create pane
        HBox action = new HBox();
        action.getChildren().addAll(withdraw, transfer, deposit);
        action.setSpacing(50);
        action.setAlignment(Pos.CENTER);
        HBox action2 = new HBox();
        action2.getChildren().addAll(quit, home);
        action2.setSpacing(50);
        action2.setAlignment(Pos.CENTER);
        GridPane accBalance = new GridPane();
        accBalance.add(overview, 0, 0);
        accBalance.add(balance, 1, 0);
        accBalance.setHgap(25);
        accBalance.setAlignment(Pos.CENTER);
        GridPane name = new GridPane();
        name.add(greeting, 0, 0);
        name.add(Fname, 1, 0);
        name.add(Lname, 2, 0);
        name.setAlignment(Pos.CENTER);
        GridPane addcheck = new GridPane();
        addcheck.add(cRec, 0, 0);
        addcheck.add(cAmount, 1, 0);
        addcheck.add(recipient,0,1);
        addcheck.add(amount,1,1);
        addcheck.setHgap(25);
        addcheck.setAlignment(Pos.CENTER);
        VBox pane = new VBox();
        if (teller || manager) {
            pane.getChildren().addAll(name, title,accLevel, accBalance, action, checkHistory, hisBox, checkAction,addcheck,add, action2);
        } else {
            pane.getChildren().addAll(name, title, accLevel, accBalance, transfer, action2);
        }
        pane.setStyle("-fx-background-color: black");
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(20);
        scene = new Scene(pane, 700, 700);
        primaryStage.setScene(scene);
    }
    public void displayAllChecks(String ssn,TableView newdata) {
        List<Check> all = new CheckQuery().getBySSN(ssn).execute();
        ObservableList<Check> foundChecks = FXCollections.observableArrayList();
        for (int i = 0; i < all.size(); i++) {
            foundChecks.add(new Check(all.get(i).getCHECK_NUMBER(), all.get(i).getRECIPIENT(), all.get(i).getAMOUNT(), all.get(i).getDATE_WRITTEN(), all.get(i).getDATE_HONORED()));
        }
        newdata.setItems(foundChecks);

        if (ssn.equals("") && all.size() == 0) {
            alertbox.display("Invalid ssn", "Can not find ssn\n Please Enter Again");
        }

    }
    public void stopButtonClicked(TableView table,List<AccountEntity> acc) {
        try {
            String ssn=acc.get(0).getSSN();
            ObservableList<Check> checkSelected, allChecks;
            allChecks = table.getItems();
            checkSelected = table.getSelectionModel().getSelectedItems();
            long dayDiff=dayDiff(checkSelected);
            String selectedNumber = checkSelected.get(0).getCHECK_NUMBER();
            if(dayDiff<=3){
                checkSelected.forEach(allChecks::remove);
                Check deleteCheck = new CheckQuery().getByCheckNumber(selectedNumber).getFirst();
                double newBalance=acc.get(0).getBALANCE()+Double.parseDouble(deleteCheck.getAMOUNT());
                acc.get(0).setBALANCE(newBalance);
                acc.get(0).update();
                balance.setText(String.valueOf(newBalance));
            deleteCheck.delete();
                displayAllChecks(ssn,ChecksTable);
            }else{
                alertbox.display("Error", "Can not stop this check");
            }
        } catch (Exception er) {
            alertbox.display("Error", "Can not find this check");
        }

    }
    public long dayDiff(ObservableList<Check> selectedCheck){
                   //Check foundCheck = new CheckQuery().getByCheckNumber(selectedNumber).getFirst();
            Date date = new Date();
            String DATE_FORMAT = "MM/dd/yyyy";
            SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
            String currentDate = sdf.format(date);
            String beforeDate = selectedCheck.get(0).getDATE_HONORED();
            System.out.println(currentDate);
            System.out.println(beforeDate);
            Date date1 = null;
            try {
                date1 = sdf.parse(currentDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Date date2 = null;
            try {
                date2 = sdf.parse(beforeDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
          //  long daydiff = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
            long diff = date2.getTime() - date1.getTime();
            return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
        }
        public void addDataToDatabase(Check newCheck,List<AccountEntity> acc) {
            //create a new customer if the SSN does not existed
            if (newCheck.add() == true) {
                //alertbox=new AlertBox();
                double newBalance=acc.get(0).getBALANCE()-Double.parseDouble(newCheck.getAMOUNT());
               acc.get(0).setBALANCE(newBalance);
               acc.get(0).update();
               balance.setText(String.valueOf(newBalance));
                alertbox.display("Successful", "New Check added");
            } else {
                //check to see if there is a duplicate SSN
                //alertbox=new AlertBox();
                alertbox.display("Unsuccessful", "Check already existed");
            }
        }
        public String honoredDate(String written){
            Date date =new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
            String now=formatter.format(date);
            Calendar c = Calendar.getInstance();
            c.setTime(new Date()); // Now use today date.
            c.add(Calendar.DATE, 3); // Adding 5 days
            String output = formatter.format(c.getTime());
            return output;
        }
    }

