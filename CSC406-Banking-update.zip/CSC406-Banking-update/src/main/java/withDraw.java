import database.Account.AccountEntity;
import database.Account.AccountQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

public class withDraw extends overView {
    int accountType;
    double AmountTransfered;
    String StringAmount;
    double savingBalance = 0.0;
    double checkingBalance = 0.0;
    ObservableList<AccountEntity> savingsAcc, checkingAcc, loanAcc, CreditAcc,CDAcc;

    public void display(Stage primaryStage, ObservableList<database> customer, int account) {

        accountType = account;
        String ssn = customer.get(0).getSSN();

        List<AccountEntity> acc = new AccountQuery().getBySSN(ssn).execute();
        for (int i = 0; i < acc.size(); i++) {
            switch (acc.get(i).getTYPE()) {
                case "Savings":
                    savingsAcc = FXCollections.observableArrayList();
                    savingsAcc.add(acc.get(i));
                    savingBalance = savingsAcc.get(0).getFUTURE_VALUE();
                    break;
                case "Checking":
                    checkingAcc = FXCollections.observableArrayList();
                    checkingAcc.add(acc.get(i));
                    checkingBalance = checkingAcc.get(0).getBALANCE();
                    break;
                case "Loan":
                    loanAcc = FXCollections.observableArrayList();
                    loanAcc.add(acc.get(i));
                    break;
                case "Credit":
                    CreditAcc = FXCollections.observableArrayList();
                    CreditAcc.add(acc.get(i));
                    break;
                case "CD":
                    CDAcc=FXCollections.observableArrayList();
                    CDAcc.add(acc.get(i));
                    break;
                default:
                    accountType = 0;
                    break;
            }
        }
        //everything is the same between both transfer except for the intro and function of the transfer button
        Text howMuch = new Text();
        howMuch.setFill(Color.WHITE);
        howMuch.setFont(Font.font(null, 20));
        TextField amount = new TextField();
        amount.setMaxSize(250, 250);
        amount.setAlignment(Pos.CENTER);
        Button submit = new Button("Submit");
        submit.setOnAction(e -> {
            double fee = 0;
            StringAmount = amount.getText();
            AmountTransfered = Double.parseDouble(StringAmount);
            if (accountType == 1) {
                if ((checkingBalance - AmountTransfered) >= 0 && AmountTransfered >= 0) {
                    double remainAccBalance = checkingBalance - AmountTransfered;
                    checkingAcc.get(0).setBALANCE(remainAccBalance);

                    if (remainAccBalance < 1000) {
                        checkingAcc.get(0).setSUBTYPE("Gold");
                    } else {
                        checkingAcc.get(0).setSUBTYPE("Platinum");
                    }
                    alertbox = new AlertBox();
                    alertbox.display("Withdraw Successful1", "Withdraw Successful");
                    checkingAcc.get(0).update();
                } else {
                    ConfirmBox comb=new ConfirmBox();
                    boolean found=false;
                    for(int i=0;i<acc.size();i++){
                        if(acc.get(i).getTYPE().equals("Savings")){
                            if(comb.display("Confirm", "withdraw form your saving acc?", 1)){
                            acc.get(i).setBALANCE(acc.get(i).getBALANCE()+checkingBalance-AmountTransfered);
                            checkingAcc.get(0).setBALANCE(0);
                            checkingAcc.get(0).update();
                            acc.get(i).update();
                            found=true;
                            break;
                            }
                        }
//                        else{
//                            alertbox = new AlertBox();
//                            alertbox.display("Withdraw unSuccessful1", "Withdraw unSuccessful");
//                   
//                        }
                    }if(found==false){
                    alertbox = new AlertBox();
                    alertbox.display("Withdraw unSuccessful1", "Withdraw unSuccessful");
                    }
                }
            } else if(accountType==2) {
                if ((savingBalance - AmountTransfered) >= 0 && AmountTransfered >= 0) {
                    if (savingBalance <= 1000) {
                        fee = 5.0;
                    } else {
                        fee = 0.0;
                    }
                    ConfirmBox confirmBox=new ConfirmBox();
                    if(fee==5&&confirmBox.display("confirm","There will be $5 fee\ncountinue?",2)){
                        savingsAcc.get(0).setFUTURE_VALUE(savingsAcc.get(0).getFUTURE_VALUE() - AmountTransfered - fee);
                        savingsAcc.get(0).update();
                            alertbox = new AlertBox();
                            alertbox.display("Withdraw Successful", "Withdraw Successful 2", accountType, customer);

                    }else{
                        System.out.println(savingsAcc.get(0).getFUTURE_VALUE());
                        System.out.println(AmountTransfered);
                        savingsAcc.get(0).setFUTURE_VALUE(savingsAcc.get(0).getFUTURE_VALUE() - AmountTransfered);
                        savingsAcc.get(0).update();
                        alertbox = new AlertBox();
                        alertbox.display("Withdraw Successful", "Withdraw Successful2", accountType, customer);

                    }
                    if(savingsAcc.get(0).getFUTURE_VALUE()<1000){
                        savingsAcc.get(0).setSUBTYPE("Gold");
                        savingsAcc.get(0).setINTEREST_RATE(0.01);
                        savingsAcc.get(0).update();
                    }else{
                        savingsAcc.get(0).setSUBTYPE("Platinum");
                        savingsAcc.get(0).setINTEREST_RATE(0.065);
                        savingsAcc.get(0).update();
                    }
                }else{
                    alertbox = new AlertBox();
                    alertbox.display("Withdraw unsuccessful", "Not enough balance", accountType, customer);
                }
               
            }else{


            }
        });
        if (accountType == 1) {
            howMuch.setText("How much do you want to draw from the checking account?");
            submit.setText("Submit");
            submit.setStyle("-fx-background-color: blue; -fx-text-fill: black");
        } else if (accountType == 2) {
            howMuch.setText("How much do you want to draw from the savings account?");
            submit.setText("Submit");
            submit.setStyle("-fx-background-color: blue; -fx-text-fill: black");
        }
        //create input amount textField

        //create buttons back and quit
        Button back = new Button("Back");
        back.setOnAction(e -> {
            if (accountType==1) {
                checking checkingAcc = new checking();
                checkingAcc.display(primaryStage, customer);
            } else {
                savings savingsAcc = new savings();
                savingsAcc.display(primaryStage, customer);
            }
        });
        back.setStyle("-fx-background-color: yellow; -fx-text-fill: black");
        Button quit = new Button("Quit");
        quit.setOnAction(e -> {
            try {
                start(primaryStage);
            } catch (Exception er) {
                er.printStackTrace();

            }
        });
        quit.setStyle("-fx-background-color: yellow; -fx-text-fill: black");

        //create pane
        HBox action = new HBox();
        action.getChildren().addAll(quit, back);
        action.setSpacing(100);
        action.setAlignment(Pos.CENTER);
        VBox pane = new VBox();
        pane.getChildren().addAll(howMuch, amount, submit, action);
        pane.setStyle("-fx-background-color: black");
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(20);
        scene = new Scene(pane, 700, 700);
        primaryStage.setScene(scene);
    }
}